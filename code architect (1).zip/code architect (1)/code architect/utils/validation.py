from models import db, Expense, Category, User
import logging

# Cấu hình logging cơ bản (có thể được đặt ở app.py hoặc config.py)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Hàm trợ giúp chung cho việc validate ID và lấy model ---
def _validate_id_and_get_model(model_class, model_id, id_name):
    try:
        validated_id = int(model_id)
        if validated_id <= 0:
            logging.warning(f"Validation Error: {id_name} không hợp lệ (ID <= 0): {model_id}")
            return None, f"{id_name} không hợp lệ.", 400
        
        obj = model_class.query.get(validated_id)
        if not obj:
            logging.warning(f"Validation Error: {id_name} '{model_id}' không tồn tại.")
            return None, f"{id_name} '{model_id}' không tồn tại.", 400
        
        return obj, None, None
    except ValueError:
        logging.warning(f"Validation Error: {id_name} phải là một số nguyên hợp lệ: {model_id}")
        return None, f"{id_name} phải là một số nguyên hợp lệ.", 400

def _validate_and_get_user(user_id):
    return _validate_id_and_get_model(User, user_id, "User ID")

def _validate_and_get_category(category_id):
    return _validate_id_and_get_model(Category, category_id, "Category ID")

def _validate_amount(amount):
    """Kiểm tra số tiền và trả về số tiền đã chuyển đổi hoặc lỗi."""
    try:
        amount = float(amount)
        if amount <= 0:
            logging.warning(f"Validation Error: Số tiền phải lớn hơn 0: {amount}")
            return None, "Số tiền phải lớn hơn 0.", 400
        return amount, None, None
    except ValueError:
        logging.warning(f"Validation Error: Số tiền không hợp lệ: {amount}")
        return None, "Số tiền không hợp lệ.", 400
    