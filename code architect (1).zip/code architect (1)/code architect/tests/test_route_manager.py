import unittest
from flask import Flask
from auto_register import RouteManager
import os

class TestRouteManager(unittest.TestCase):
    def setUp(self):
        """Setup trước mỗi test case"""
        # Tạo một instance mới của Flask app cho mỗi test
        test_app = Flask(__name__)
        test_app.config['TESTING'] = True
        self.app = test_app.test_client()
        self.route_manager = RouteManager(test_app)
        
    def test_route_manager_initialization(self):
        """Kiểm tra việc khởi tạo RouteManager"""
        self.assertIsNotNone(self.route_manager.app)
        self.assertIsNotNone(self.route_manager.routes_path)
        self.assertTrue(os.path.exists(self.route_manager.routes_path))
        
    def test_routes_structure(self):
        """Kiểm tra cấu trúc của các route"""
        # Kiểm tra xem thư mục routes có tồn tại không
        self.assertTrue(os.path.exists('routes'))
        
        # Kiểm tra xem có file routes trong thư mục không
        files = os.listdir('routes')
        self.assertGreater(len(files), 0)
        
    def test_blueprint_registration(self):
        """Kiểm tra việc đăng ký blueprint"""
        # Kiểm tra xem các blueprint đã được đăng ký chưa
        with self.route_manager.app.app_context():
            # Kiểm tra xem có blueprint nào được đăng ký không
            blueprints = self.route_manager.app.blueprints
            self.assertGreater(len(blueprints), 0)
            
            # Kiểm tra xem có route /expense không
            response = self.app.get('/expenses')
            self.assertEqual(response.status_code, 200)
            
    def test_route_manager_methods(self):
        """Kiểm tra các phương thức của RouteManager"""
        # Kiểm tra phương thức get_routes_path
        routes_path = self.route_manager.get_routes_path('routes')
        self.assertTrue(os.path.exists(routes_path))
        
        # Kiểm tra phương thức is_valid_route_file
        valid_file = 'expense_routes.py'
        invalid_file = 'test.txt'
        self.assertTrue(self.route_manager.is_valid_route_file(valid_file))
        self.assertFalse(self.route_manager.is_valid_route_file(invalid_file))

if __name__ == '__main__':
    unittest.main()