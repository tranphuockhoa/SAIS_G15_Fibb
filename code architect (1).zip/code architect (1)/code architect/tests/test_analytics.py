import unittest
from flask import Flask
from app import app
from services.analytics_service import get_enriched_data, compare_with_target, compare_with_previous
from datetime import datetime

class TestAnalytics(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.current_month = datetime.now().strftime('%Y-%m')
        self.previous_month = (datetime.now() - relativedelta(months=1)).strftime('%Y-%m')

    def test_compare_with_target(self):
        """Kiểm tra việc so sánh với mục tiêu chi tiêu"""
        # Trường hợp vượt mục tiêu
        result = compare_with_target(1000, 800)
        self.assertTrue(result['exceeded'])
        self.assertEqual(result['difference'], 200)

        # Trường hợp không vượt mục tiêu
        result = compare_with_target(800, 1000)
        self.assertFalse(result['exceeded'])
        self.assertEqual(result['difference'], 0)

        # Trường hợp không có mục tiêu
        result = compare_with_target(1000, None)
        self.assertIsNone(result)

    def test_compare_with_previous(self):
        """Kiểm tra việc so sánh giữa các tháng"""
        # Trường hợp tăng chi tiêu
        result = compare_with_previous(1000, 800)
        self.assertTrue(result['increased'])
        self.assertEqual(result['difference'], 200)

        # Trường hợp giảm chi tiêu
        result = compare_with_previous(800, 1000)
        self.assertFalse(result['increased'])
        self.assertEqual(result['difference'], -200)

        # Trường hợp không có dữ liệu tháng trước
        result = compare_with_previous(1000, None)
        self.assertIsNone(result)

    def test_get_enriched_data(self):
        """Kiểm tra việc lấy dữ liệu phân tích"""
        # Gọi endpoint để lấy dữ liệu
        response = self.app.get('/analytics/')
        self.assertEqual(response.status_code, 200)
        
        data = response.get_json()
        self.assertIn('current', data)
        self.assertIn('previous', data)
        self.assertIn('month_to_month', data)

        # Kiểm tra cấu trúc dữ liệu trả về
        self.assertIn('value', data['current'])
        self.assertIn('target', data['current'])
        self.assertIn('comparison', data['current'])
        self.assertIn('value', data['previous'])
        self.assertIn('increased', data['month_to_month'])
        self.assertIn('difference', data['month_to_month'])

    def test_set_target(self):
        """Kiểm tra việc đặt mục tiêu chi tiêu"""
        # Đặt mục tiêu
        response = self.app.post('/analytics/set-target', json={
            'month': self.current_month,
            'target_value': 800
        })
        self.assertEqual(response.status_code, 200)
        
        # Kiểm tra response
        data = response.get_json()
        self.assertIn('message', data)
        self.assertEqual(data['message'], 'Target updated successfully')

if __name__ == '__main__':
    unittest.main()
