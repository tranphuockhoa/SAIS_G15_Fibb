from models import db, MonthlyExpense
from schemas import MonthlyExpenseSchema
from datetime import datetime
from dateutil.relativedelta import relativedelta

from services.monthly_expense_helper import (
    get_current_and_previous_month_records,
    get_record_value,
    
)


def compute_recommendation(pct):
    if pct is None:
        return 'No previous data'
    if pct > 10:
        return 'Excellent growth – consider expanding'
    if pct > 0:
        return 'Positive trend – maintain course'
    if pct == 0:
        return 'Stable – no action needed'
    if pct >= -10:
        return 'Slight dip – investigate'
    return 'Significant drop – urgent review'

def enrich_monthly_records(data_list):
    """
    Tính phần trăm thay đổi và khuyến nghị cho mỗi bản ghi.
    Trả về danh sách đã bổ sung field 'pct_change' và 'recommendation'.
    """

    for i, rec in enumerate(data_list):
        if i == 0:
            rec['pct_change'] = None
            rec['recommendation'] = compute_recommendation(None)
            
        else:
            prev = data_list[i - 1]['total_amount']
            pct = (rec['total_amount'] - prev) / prev * 100
            rec['pct_change'] = round(pct, 2)
            rec['recommendation'] = compute_recommendation(pct)
    return data_list

def get_enriched_data(user_id): # <-- THÊM user_id vào đây
    # Chắc chắn rằng get_current_and_previous_month_records cũng nhận user_id
    current_record, previous_record = get_current_and_previous_month_records(user_id) # <-- Truyền user_id vào đây

    current_value = get_record_value(current_record)
    previous_value = get_record_value(previous_record)
    target_value = current_record.target_value if current_record else None

    enriched = {
        'current': {
            'value': current_value,
            'target': target_value,
            'comparison': compare_with_target(current_value, target_value)
        },
        'previous': {
            'value': previous_value
        },
        'month_to_month': compare_with_previous(current_value, previous_value)
    }
    
    return enriched

def compare_with_target(current_value, target_value):
    if target_value is not None:
        return {
            'exceeded': current_value > target_value,
            'difference': current_value - target_value if current_value > target_value else 0
        }
    return None

def compare_with_previous(current_value, previous_value):
    if previous_value is not None:
        return {
            'increased': current_value > previous_value,
            'difference': current_value - previous_value
        }
    return None

# Hãy chắc chắn rằng hàm này nhận 'user_id'
def get_monthly_data(user_id):
    # Bạn có thể muốn chuyển đổi user_id sang int nếu nó chưa phải là int
    try:
        user_id = int(user_id)
    except ValueError:
        # Xử lý lỗi nếu user_id không phải là số hợp lệ (tùy chọn)
        # Trong trường hợp này, Flask đã xử lý với <int:user_id> rồi, nhưng để an toàn.
        pass

    # Truy vấn các bản ghi MonthlyExpense cho user_id cụ thể
    # Đây là dòng quan trọng cần có filter_by(user_id=user_id)
    monthly_expenses = MonthlyExpense.query.filter_by(user_id=user_id).all()

    # Kiểm tra xem có dữ liệu không
    if not monthly_expenses:
        # Nếu không tìm thấy dữ liệu cho user_id này, trả về một danh sách rỗng
        # hoặc một thông báo phù hợp.
        return [] # Hoặc jsonify({'message': 'No monthly data found for this user'}), 200

    # Serialize dữ liệu
    # Đảm bảo MonthlyExpenseSchema được import và khởi tạo đúng cách
    from schemas import MonthlyExpenseSchema # Ví dụ import
    monthly_expense_schema = MonthlyExpenseSchema(many=True)
    serialized_data = monthly_expense_schema.dump(monthly_expenses)

    return serialized_data


