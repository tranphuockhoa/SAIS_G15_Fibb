from models import db, MonthlyExpense
from datetime import datetime
from dateutil.relativedelta import relativedelta
from schemas import MonthlyExpenseSchema
from decimal import Decimal


def create_monthly_record(user_id: int, year: int, month: int, value: float) -> MonthlyExpense:
    """
    Tạo và lưu một bản ghi MonthlyExpense mới.
    Trả về object MonthlyExpense vừa tạo.
    """
    try:
        record = MonthlyExpense(
            user_id=user_id,
            year=year,
            month=month,
            total_amount=Decimal(value)
        )
        db.session.add(record)
        db.session.commit()
        return record
    except Exception as e:
        db.session.rollback()
        raise e

'''def get_monthly_data(user_id: int) -> list:
    """
    Truy vấn tất cả bản ghi MonthlyExpense của user theo thứ tự tháng,
    rồi chuyển thành list of dict.
    """
    raw = MonthlyExpense.query.filter_by(user_id=user_id).order_by(MonthlyExpense.year, MonthlyExpense.month).all()
    return [record.to_dict() for record in raw]'''

def get_monthly_record(user_id: int, year: int, month: int):
    return MonthlyExpense.query.filter_by(
        user_id=user_id,
        year=year,
        month=month
    ).first()

def get_current_and_previous_month_records(user_id: int):
    """Lấy bản ghi của tháng hiện tại và tháng trước."""
    now = datetime.now()
    current_year = now.year
    current_month = now.month
    previous_year = now.year if now.month > 1 else now.year - 1
    previous_month = now.month - 1 if now.month > 1 else 12
    
    current_record = get_monthly_record(user_id, current_year, current_month)
    previous_record = get_monthly_record(user_id, previous_year, previous_month)
    
    return current_record, previous_record

def get_record_value(record):
    return float(record.total_amount) if record else 0
