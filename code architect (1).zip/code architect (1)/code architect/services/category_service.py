from flask import jsonify
from models import db, Category # Đảm bảo bạn đã import db và Category từ models.py

def get_all_categories_logic():
    categories = Category.query.all()
    result = [{"id": cat.id, "name": cat.name} for cat in categories]
    return jsonify(result), 200

def create_category_logic(category_name):

    category_name = category_name.strip()

    if not category_name:
        return None, "Tên danh mục không được để trống", 400

    # Kiểm tra xem danh mục đã tồn tại trong CSDL chưa
    # Sử dụng .ilike() để tìm kiếm không phân biệt chữ hoa, chữ thường
    existing_category = Category.query.filter(Category.name.ilike(category_name)).first()
    if existing_category:
        return None, f"Danh mục '{category_name}' đã tồn tại.", 409 

    # Tạo một đối tượng Category mới
    new_category_obj = Category(name=category_name)
    
    # Thêm vào session và commit để lưu vào CSDL
    db.session.add(new_category_obj)
    db.session.commit()
    
    return {"id": new_category_obj.id, "name": new_category_obj.name}, None, 201