from datetime import datetime, UTC
from flask import jsonify
from models import db, Expense, User, Category
import logging
import time
from sqlalchemy.exc import IntegrityError, DataError, SQLAlchemyError
from datetime import datetime, UTC
from utils.validation import _validate_amount, _validate_and_get_category, _validate_and_get_user
from utils.date_parser import *

# # Cấu hình logging cơ bản (có thể được đặt ở app.py hoặc config.py)
# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# # --- Hàm trợ giúp chung cho việc validate ID và lấy model ---
# def _validate_id_and_get_model(model_class, model_id, id_name):
#     try:
#         validated_id = int(model_id)
#         if validated_id <= 0:
#             logging.warning(f"Validation Error: {id_name} không hợp lệ (ID <= 0): {model_id}")
#             return None, f"{id_name} không hợp lệ.", 400
        
#         obj = model_class.query.get(validated_id)
#         if not obj:
#             logging.warning(f"Validation Error: {id_name} '{model_id}' không tồn tại.")
#             return None, f"{id_name} '{model_id}' không tồn tại.", 400
        
#         return obj, None, None
#     except ValueError:
#         logging.warning(f"Validation Error: {id_name} phải là một số nguyên hợp lệ: {model_id}")
#         return None, f"{id_name} phải là một số nguyên hợp lệ.", 400

# def _validate_and_get_user(user_id):
#     return _validate_id_and_get_model(User, user_id, "User ID")

# def _validate_and_get_category(category_id):
#     return _validate_id_and_get_model(Category, category_id, "Category ID")

# def _validate_amount(amount):
#     """Kiểm tra số tiền và trả về số tiền đã chuyển đổi hoặc lỗi."""
#     try:
#         amount = float(amount)
#         if amount <= 0:
#             logging.warning(f"Validation Error: Số tiền phải lớn hơn 0: {amount}")
#             return None, "Số tiền phải lớn hơn 0.", 400
#         return amount, None, None
#     except ValueError:
#         logging.warning(f"Validation Error: Số tiền không hợp lệ: {amount}")
#         return None, "Số tiền không hợp lệ.", 400
# Cấu hình logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
# Nếu bạn muốn logger hiển thị ra console, hãy thêm handler
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)


MAX_RETRIES = 3
RETRY_DELAY = 0.5

def _parse_date(date_str):
    if date_str:
        try:
            return datetime.strptime(date_str, '%Y-%m-%d').date(), None, None
        except ValueError:
            logging.warning(f"Validation Error: Định dạng ngày không hợp lệ: {date_str}")
            return None, "Định dạng ngày không hợp lệ. Vui lòng sử dụng YYYY-MM-DD", 400
    return datetime.now(UTC).date(), None, None

# --- Hàm logic chính ---
def get_all_expenses_logic():
    try:
        expenses = Expense.query.all()
        result = []
        for exp in expenses:
            category_name = exp.category.name if exp.category else None
            result.append({
                "expense_id": exp.expense_id, # Đảm bảo tên trường id là nhất quán nếu có exp.id
                "user_id": exp.user_id,
                "amount": exp.amount,
                "category_id": exp.category_id,
                "category_name": category_name,
                "note": exp.note,
                "date": exp.date.isoformat()
            })
        logging.info("Successfully retrieved all expenses.")
        return jsonify(result), 200
    except Exception as e:
        logging.error(f"Error retrieving all expenses: {e}", exc_info=True)
        db.session.rollback() # Đảm bảo rollback nếu có lỗi DB trong quá trình truy vấn
        return jsonify({"error": "Không thể lấy danh sách chi tiêu. Vui lòng thử lại sau."}), 500

def create_expense_logic(user_id, amount, category_id, note, date_str):
    # Khôi phục từ lỗi (Retry) - Một ví dụ đơn giản cho thao tác DB
    MAX_RETRIES = 3
    RETRY_DELAY = 0.5 # giây

    for attempt in range(MAX_RETRIES):
        try:
            # I. Ngăn ngừa lỗi (Prevent Faults):
            # Xác thực đầu vào
            user, error_message, status_code = _validate_and_get_user(user_id)
            if error_message:
                logging.warning(f"Create Expense Validation Failed (User): {error_message}")
                return None, error_message, status_code

            category, error_message, status_code = _validate_and_get_category(category_id)
            if error_message:
                logging.warning(f"Create Expense Validation Failed (Category): {error_message}")
                return None, error_message, status_code

            valid_amount, error_message, status_code = _validate_amount(amount)
            if error_message:
                logging.warning(f"Create Expense Validation Failed (Amount): {error_message}")
                return None, error_message, status_code
            
            expense_date, error_message, status_code = parse_date(date_str)
            if error_message:
                logging.warning(f"Create Expense Validation Failed (Date): {error_message}")
                return None, error_message, status_code
            
            # Giao dịch nguyên tố: Bắt đầu giao dịch
            new_expense = Expense(
                user_id=user.id,
                category_id=category.id,
                amount=valid_amount,
                note=note,
                date=expense_date
            )
            db.session.add(new_expense)
            db.session.commit() # Hoàn thành giao dịch

            logging.info(f"Expense created successfully: User ID={user.id}, Amount={valid_amount}")
            return {
                "id": new_expense.expense_id,
                "user_id": new_expense.user_id,
                "amount": new_expense.amount,
                "category_id": new_expense.category_id,
                "category_name": category.name, 
                "note": new_expense.note,
                "date": new_expense.date.isoformat()
            }, None, 201

        # II. Phát hiện lỗi (Detect Faults) & III. Phục hồi từ lỗi (Recover from Faults):
        except Exception as e:
            # Phát hiện ngoại lệ
            db.session.rollback() # Đảm bảo rollback trong trường hợp có lỗi
            logging.error(f"Attempt {attempt + 1} failed to create expense. Error: {e}", exc_info=True)

            # Thử lại
            if attempt < MAX_RETRIES - 1:
                logging.info(f"Retrying create expense operation in {RETRY_DELAY} seconds...")
                time.sleep(RETRY_DELAY)
            else:
                # Xử lý ngoại lệ (Trả về thông báo lỗi có ý nghĩa)
                logging.critical(f"All {MAX_RETRIES} attempts failed to create expense for user {user_id}. Final error: {e}")
                return None, "Không thể ghi nhận chi tiêu. Vui lòng thử lại sau.", 500

def get_expenses_by_user_logic(user_id):
    try:
        user, error_message, status_code = _validate_and_get_user(user_id)
        if error_message:
            return None, error_message, status_code

        user_expenses = Expense.query.filter_by(user_id=user.id).all()
        result = []
        for exp in user_expenses:
            category_name = exp.category.name if exp.category else None
            result.append({
                "id": exp.id,
                "user_id": exp.user_id,
                "amount": exp.amount,
                "category_id": exp.category_id,
                "category_name": category_name,
                "note": exp.note,
                "date": exp.date.isoformat()
            })
        logging.info(f"Successfully retrieved expenses for user ID: {user_id}")
        return jsonify(result), 200
    except Exception as e:
        logging.error(f"Error retrieving expenses for user ID {user_id}: {e}", exc_info=True)
        db.session.rollback() # Đảm bảo rollback nếu có lỗi DB trong quá trình truy vấn
        return jsonify({"error": "Không thể lấy danh sách chi tiêu của người dùng này. Vui lòng thử lại sau."}), 500
    
def get_expense_by_id_logic(expense_id):
    """
    Lấy thông tin chi tiết của một chi tiêu dựa trên expense_id.
    """
    try:
        # Chuyển expense_id sang số nguyên
        try:
            expense_id = int(expense_id)
        except ValueError:
            return None, "ID chi tiêu không hợp lệ. Vui lòng cung cấp một số nguyên.", 400

        # Tìm chi tiêu trong database
        # Sử dụng join để lấy thông tin user và category cùng lúc
        expense = db.session.query(Expense, User, Category).\
            join(User, Expense.user_id == User.id).\
            join(Category, Expense.category_id == Category.id).\
            filter(Expense.expense_id == expense_id).first()

        if not expense:
            return None, f"Không tìm thấy chi tiêu với ID: {expense_id}", 404

        # expense là một tuple (Expense_object, User_object, Category_object)
        expense_obj, user_obj, category_obj = expense

        # Định dạng dữ liệu để trả về
        formatted_expense = {
            "id": expense_obj.expense_id,
            "user_id": expense_obj.user_id,
            "username": user_obj.username, # Thêm tên user
            "amount": float(expense_obj.amount),
            "category_id": expense_obj.category_id,
            "category_name": category_obj.name, # Thêm tên category
            "note": expense_obj.note,
            "date": expense_obj.date.strftime('%Y-%m-%d')
        }
        return formatted_expense, None, 200

    except SQLAlchemyError as e:
        logger.error(f"Lỗi database khi lấy chi tiêu theo ID {expense_id}: {e}", exc_info=True)
        return None, "Lỗi server: Không thể truy xuất chi tiêu từ cơ sở dữ liệu.", 500
    except Exception as e:
        logger.error(f"Lỗi không xác định khi lấy chi tiêu theo ID {expense_id}: {e}", exc_info=True)
        return None, "Lỗi server: Đã xảy ra lỗi không mong muốn.", 500
