from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, UTC
db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    expenses = db.relationship('Expense', backref='user', lazy=True)

class Category(db.Model):
    __tablename__ = 'category'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    expenses = db.relationship('Expense', backref='category', lazy=True)

class Expense(db.Model):
    __tablename__ = 'expense'
    expense_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    note = db.Column(db.String(200), nullable=True)
    date = db.Column(db.Date, nullable=False, default=datetime.now(UTC)) 

class DailyExpense(db.Model):
    __tablename__ = 'daily_expense'
    user_id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, primary_key=True)
    total_amount = db.Column(db.Numeric(15, 2), nullable=False)

    def __repr__(self):
        return f'<DailyExpense user_id={self.user_id} date={self.date} amount={self.total_amount}>'

    def to_dict(self):
        return {
            'user_id': self.user_id,
            'date': self.date.strftime('%Y-%m-%d'),
            'total_amount': float(self.total_amount)
        }

class MonthlyExpense(db.Model):
    __tablename__ = 'monthly_expense'
    user_id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer, primary_key=True)
    month = db.Column(db.Integer, primary_key=True)
    total_amount = db.Column(db.Numeric(15, 2), nullable=False)
    
    # THÊM DÒNG NÀY ĐỂ ĐỊNH NGHĨA CỘT TARGET_VALUE
    target_value = db.Column(db.Numeric(15, 2), nullable=True, default=0.00) 

    # Cập nhật __repr__ để bao gồm target_value (tùy chọn nhưng tốt cho debug)
    def __repr__(self):
        return f'<MonthlyExpense user_id={self.user_id} year={self.year} month={self.month} amount={self.total_amount} target={self.target_value}>'

    # Cập nhật to_dict để bao gồm target_value
    def to_dict(self):
        return {
            'user_id': self.user_id,
            'year': self.year,
            'month': self.month,
            'total_amount': float(self.total_amount),
            'target_value': float(self.target_value) if self.target_value is not None else None # Đảm bảo xử lý None
        }

class YearlyExpense(db.Model):
    __tablename__ = 'yearly_expense'
    user_id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer, primary_key=True)
    total_amount = db.Column(db.Numeric(15, 2), nullable=False)

    def __repr__(self):
        return f'<YearlyExpense user_id={self.user_id} year={self.year} amount={self.total_amount}>'

    def to_dict(self):
        return {
            'user_id': self.user_id,
            'year': self.year,
            'total_amount': float(self.total_amount)
        }