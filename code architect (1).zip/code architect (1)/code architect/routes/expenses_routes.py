from flask import Blueprint, request, jsonify
from services.expense_service import get_all_expenses_logic, create_expense_logic, get_expenses_by_user_logic, get_expense_by_id_logic
from api_validation import validate_required_fields

expense_bp = Blueprint('expense_routes', __name__)

@expense_bp.route('/', methods=['POST'])
def record_expenses(): # Đổi tên hàm thành số nhiều để dễ hiểu hơn
    data = request.get_json()

    # Định nghĩa các trường bắt buộc
    required_fields = ['user_id', 'amount', 'category_id', 'note']

    # Danh sách để lưu trữ các chi tiêu đã xử lý thành công và thất bại
    successful_expenses = []
    failed_expenses = []

    # --- BƯỚC QUAN TRỌNG: Xử lý cả trường hợp gửi MỘT chi tiêu hoặc NHIỀU chi tiêu ---
    # Nếu dữ liệu không phải là một danh sách, coi nó như một chi tiêu đơn lẻ và đưa vào danh sách để xử lý
    if not isinstance(data, list):
        data = [data] # Biến đối tượng đơn lẻ thành một danh sách chứa đối tượng đó

    # Lặp qua từng chi tiêu trong danh sách (dù là một hay nhiều)
    for index, expense_data in enumerate(data):
        # 1. Validate các trường bắt buộc cho TỪNG chi tiêu
        error_response, status_code = validate_required_fields(expense_data, required_fields)
        if error_response:
            failed_expenses.append({
                "index": index,
                "data": expense_data,
                "error": error_response.json["error"], # Lấy thông báo lỗi cụ thể từ jsonify
                "status_code": status_code
            })
            continue # Bỏ qua chi tiêu này và tiếp tục với chi tiêu tiếp theo

        # 2. Trích xuất dữ liệu từ chi tiêu hiện tại
        user_id = expense_data['user_id']
        amount = expense_data['amount']
        category_id = expense_data['category_id']
        note = expense_data.get('note')
        date_str = expense_data.get('date_str') # Sửa thành date_str để khớp với payload

        # 3. Gọi logic tạo chi tiêu (hàm này vẫn xử lý MỘT chi tiêu một lúc)
        new_expense, error_message, status_code = create_expense_logic(
            user_id, amount, category_id, note, date_str
        )

        if error_message:
            failed_expenses.append({
                "index": index,
                "data": expense_data,
                "error": error_message,
                "status_code": status_code
            })
        else:
            successful_expenses.append(new_expense) # new_expense là dict đã format từ service

    # Trả về phản hồi tổng hợp sau khi xử lý tất cả các chi tiêu
    if failed_expenses:
        response = {
            "message": "Hoàn tất xử lý. Một số chi tiêu không thể ghi nhận.",
            "successful_count": len(successful_expenses),
            "failed_count": len(failed_expenses),
            "successful_expenses": successful_expenses,
            "failed_details": failed_expenses
        }
        # Nếu có ít nhất một chi tiêu thành công, trả về 207 Multi-Status
        # Nếu tất cả đều thất bại, trả về 400 Bad Request
        if successful_expenses:
            return jsonify(response), 207
        else:
            return jsonify(response), 400
    else:
        # Nếu tất cả đều thành công
        message = "Tất cả chi tiêu đã được ghi nhận thành công"
        # Nếu chỉ có một chi tiêu được gửi ban đầu, trả về message đơn giản hơn
        if len(data) == 1:
            return jsonify({"message": message, "expense": successful_expenses[0]}), 201
        else:
            return jsonify({"message": message, "expenses": successful_expenses}), 201


@expense_bp.route('/', methods=['GET'])
def get_expenses():
    """
    Lấy danh sách tất cả các chi tiêu hoặc chi tiêu của một người dùng cụ thể.
    Yêu cầu (tùy chọn): Tham số query 'user_id'.
    Phản hồi: Danh sách các đối tượng chi tiêu.
    """
    user_id = request.args.get('user_id')
    if user_id:
        # Bạn có thể muốn thêm validate_required_fields cho user_id ở đây nếu cần
        # Ví dụ: if not user_id.isdigit(): return ...
        return get_expenses_by_user_logic(user_id)
    else:
        return get_all_expenses_logic()
    
@expense_bp.route('/<int:expense_id>', methods=['GET'])
def get_expense_detail(expense_id):
    """
    Lấy thông tin chi tiết của một chi tiêu cụ thể bằng ID.
    URL: /expenses/<expense_id>
    Method: GET
    Phản hồi: Đối tượng chi tiêu nếu tìm thấy, hoặc thông báo lỗi.
    """
    # Gọi hàm logic để lấy chi tiêu
    expense_detail, error_message, status_code = get_expense_by_id_logic(expense_id)

    if error_message:
        return jsonify({"error": error_message}), status_code
    
    return jsonify({"message": "Chi tiêu được tìm thấy", "expense": expense_detail}), status_code
