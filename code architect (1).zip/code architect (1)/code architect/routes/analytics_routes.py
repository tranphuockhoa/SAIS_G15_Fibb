from flask import Blueprint, render_template, request, redirect, url_for, jsonify, flash
from decimal import Decimal
from app import app, db
from models import MonthlyExpense, db
from schemas import MonthlyExpenseSchema
from services.analytics_service import enrich_monthly_records, get_monthly_data,get_enriched_data 
from services.monthly_expense_helper import create_monthly_record,get_current_and_previous_month_records
analytics_bp = Blueprint('analytics_routes', __name__)


@analytics_bp.route('/<int:user_id>', methods=['GET', 'POST'])
def index(user_id):
    if request.method == 'POST':
        data = request.get_json()
        month_str = data.get('month', '')
        value = data.get('value')
        try:
            value = float(value)
            # Extract year and month from month_str (format: YYYY-MM)
            year, month = map(int, month_str.split('-'))
            create_monthly_record(user_id, year, month, value)
            return jsonify({'status': 'success', 'message': 'Record created successfully'})
        except Exception as e:
            return jsonify({'status': 'error', 'message': str(e)}), 400

    # Get and return enriched data
    data_list = get_monthly_data(user_id)
    enriched = enrich_monthly_records(data_list)
    
    return jsonify({
        'status': 'success',
        'data': enriched
    })

# --- Route để lấy dữ liệu chi tiết theo tháng (như bạn đã sửa) ---
@analytics_bp.route('/api/data/<int:user_id>', methods=['GET'])
def api_data(user_id):
    try:
        # Lấy dữ liệu thô từ service (đã được lọc theo user_id)
        data_list = get_monthly_data(user_id) 
        
        # Làm giàu dữ liệu với pct_change và recommendation
        enriched_data = enrich_monthly_records(data_list) 
        
        return jsonify({"status": "success", "data": enriched_data}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- Route mới để lấy dữ liệu tổng quan cho tháng hiện tại và tháng trước ---
@analytics_bp.route('/api/overview/<int:user_id>', methods=['GET'])
def api_overview(user_id):
    try:
        # Cập nhật get_enriched_data để nhận user_id nếu nó cần
        # Ví dụ: sửa get_enriched_data(user_id) trong services/analytics_service.py
        enriched_overview = get_enriched_data(user_id) 
        return jsonify({"status": "success", "overview": enriched_overview}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

'''@app.route('/monthly_expenses', methods=['POST'])
def add_monthly_expense():
    data = request.get_json()
    user_id = data.get('user_id')
    year = data.get('year')
    month = data.get('month')
    total_amount = Decimal(data.get('total_amount'))
    target_value = Decimal(data.get('target_value')) # <--- Lấy target_value từ request

    if not all([user_id, year, month, total_amount, target_value]):
        return jsonify({"message": "Thiếu thông tin cần thiết"}), 400

    new_expense = MonthlyExpense(
        user_id=user_id,
        year=year,
        month=month,
        total_amount=total_amount,
        target_value=target_value # <--- Truyền target_value vào đây
    )
    db.session.add(new_expense)
    try:
        db.session.commit()
        return jsonify({"message": "Thêm chi tiêu tháng thành công", "expense": new_expense.to_dict()}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Lỗi khi thêm chi tiêu tháng: {str(e)}"}), 500'''

# Ví dụ cho hàm cập nhật (PUT)
@app.route('/monthly_expenses/<int:user_id>/<int:year>/<int:month>', methods=['PUT'])
def update_monthly_expense(user_id, year, month):
    data = request.get_json()
    
    expense = MonthlyExpense.query.filter_by(user_id=user_id, year=year, month=month).first()
    
    if not expense:
        return jsonify({"message": "Không tìm thấy bản ghi"}), 404

    if 'total_amount' in data:
        expense.total_amount = Decimal(data.get('total_amount'))
    if 'target_value' in data: # <--- Cập nhật target_value nếu có trong request
        expense.target_value = Decimal(data.get('target_value'))
    
    try:
        db.session.commit()
        return jsonify({"message": "Cập nhật chi tiêu tháng thành công", "expense": expense.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Lỗi khi cập nhật chi tiêu tháng: {str(e)}"}), 500

@analytics_bp.route('/api/target/<int:user_id>', methods=['POST']) # Thêm user_id vào route
def set_target(user_id): # Nhận user_id làm tham số
    data = request.get_json()
    month_str = data.get('month')
    target_value = float(data.get('target_value', 0))
    
    if not month_str:
        return jsonify({'error': 'Thiếu trường "month" trong request body.'}), 400

    try:
        year, month = map(int, month_str.split('-'))
    except ValueError:
        return jsonify({'error': 'Định dạng tháng không hợp lệ. Vui lòng sử dụng YYYY-MM.'}), 400
    
    try:
        record = MonthlyExpense.query.filter_by(
            user_id=user_id, # user_id đã được định nghĩa
            year=year,
            month=month
        ).first()
        if record:
            record.target_value = target_value
            db.session.add(record) # Đảm bảo thêm record vào session trước khi commit nếu nó là mới
            db.session.commit()
            return jsonify({'message': 'Mục tiêu đã được cập nhật thành công'}), 200
        
        # Nếu không tìm thấy bản ghi, bạn có thể tạo mới ở đây nếu muốn
        return jsonify({'error': f'Không tìm thấy bản ghi chi tiêu tháng cho user {user_id} vào {month_str}.'}), 404
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Lỗi server khi cập nhật mục tiêu: {str(e)}'}), 500
    
