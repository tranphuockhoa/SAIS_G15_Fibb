from flask import Flask, jsonify,request
from flask_marshmallow import Marshmallow
from decimal import Decimal
from models import db,MonthlyExpense 
ma = Marshmallow()

# from routes.expenses_routes import expense_bp
# from routes.home_route import home_bp # Blueprint cho route home

from RouteManager import RouteManager

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:Kh123456%40@localhost/architecture'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:123456@localhost/DB_QuanLyTaiChinhCaNhan'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

RouteManager(app)

@app.route('/test-add-monthly-expense', methods=['POST'])
def test_add_monthly_expense():
    data = request.get_json()

    user_id = data.get('user_id')
    year = data.get('year')
    month = data.get('month')
    total_amount = data.get('total_amount')
    target_value = data.get('target_value') 

    if not all([user_id, year, month, total_amount, target_value is not None]):
        return jsonify({"status": "error", "message": "Thiếu thông tin. Cần user_id, year, month, total_amount, target_value."}), 400

    try:
        total_amount_decimal = Decimal(str(total_amount))
        target_value_decimal = Decimal(str(target_value))

        existing_record = MonthlyExpense.query.filter_by(
            user_id=user_id, year=year, month=month
        ).first()

        if existing_record:
            existing_record.total_amount = total_amount_decimal
            existing_record.target_value = target_value_decimal
            db.session.add(existing_record)
            message = "Cập nhật bản ghi chi tiêu tháng thành công."
        else:
            new_expense = MonthlyExpense(
                user_id=user_id,
                year=year,
                month=month,
                total_amount=total_amount_decimal,
                target_value=target_value_decimal
            )
            db.session.add(new_expense)
            message = "Thêm bản ghi chi tiêu tháng mới thành công."

        db.session.commit()
        return jsonify({
            "status": "success",
            "message": message,
            "data": {
                "user_id": user_id,
                "year": year,
                "month": month,
                "total_amount": float(total_amount_decimal),
                "target_value": float(target_value_decimal)
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"status": "error", "message": f"Lỗi xử lý dữ liệu: {str(e)}"}), 500

if __name__ == '__main__':
    # Tạo bảng CSDL khi ứng dụng chạy lần đầu
    with app.app_context():
        db.create_all()
    app.run(debug=True)