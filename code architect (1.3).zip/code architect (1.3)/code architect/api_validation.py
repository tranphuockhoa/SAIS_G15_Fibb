# api_validation.py
from flask import jsonify

def validate_required_fields(data, required_fields):
    if not data:
        return jsonify({"error": "Dữ liệu yêu cầu không được để trống"}), 400

    missing_fields = [field for field in required_fields if field not in data]

    if missing_fields:
        # Đảm bảo dòng này đã được sửa đúng
        error_message = f"Thiếu các trường bắt buộc: {', '.join(f"'{f}'" for f in missing_fields)}"
        return jsonify({"error": error_message}), 400

    return None, None