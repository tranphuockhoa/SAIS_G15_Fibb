import os
import importlib
import inspect
import sys
import traceback

# Add current directory to sys.path if not already present
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class RouteManager:
    def __init__(self, app):
        self.app = app
        self.register_blueprints() 
    
    def get_routes_path(self, folder_name):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base_dir, folder_name)

    def _get_module_if_valid_and_importable(self, folder_name, filename):
        """
        Kiểm tra tính hợp lệ của file và cố gắng import module.
        Trả về module nếu thành công, ngược lại trả về None.
        """
        # Condition 1: Check if the file is a valid Python route file
        if not self.is_valid_route_file(filename):
            # print(f"Skipping invalid file: {filename}") # Optional: for more verbose debugging
            return None

        # Condition 2: Attempt to import the module
        # The import_route_module already handles printing errors and returns None on failure
        module = self.import_route_module(folder_name, filename)
        return module # Will be None if import failed, otherwise the module object


    
    def register_blueprints(self, folder_name='routes'):
        path = self.get_routes_path(folder_name)
        if not os.path.exists(path):
            print(f"❌ Không tìm thấy thư mục routes: {path}")
            return

        for filename in os.listdir(path):

            if not self.is_valid_route_file(filename):
                continue

            module = self.import_route_module(folder_name, filename)
            if not module:
                continue
            
            blueprints = self.find_blueprints(module)
            prefix = self.generate_prefix_from_module(module)

            for bp in blueprints:
                self.app.register_blueprint(bp, url_prefix=prefix)
                print(f"✅ Đã đăng ký {bp.name} từ {module.__name__} → URL prefix: {prefix}")

    def is_valid_route_file(self, filename):
        """Kiểm tra tên file có hợp lệ không (.py và không phải __init__.py)"""
        return filename.endswith('.py') and not filename.startswith('__')

    def import_route_module(self, folder_name, filename):
        """Import module từ tên file"""
        module_name = filename[:-3] 
        full_path = f"{folder_name}.{module_name}".replace('/', '.').replace('\\', '.')
        try:
            return importlib.import_module(full_path)
        except Exception as e:
            traceback.print_exc()
            print(f"⚠️ Lỗi import {full_path}")
            return None
            # print(f"⚠️ Lỗi import {full_path}: {e.__class__.__name__} → {e}")       
            # return None

    def find_blueprints(self, module):
        """Tìm tất cả biến kết thúc bằng _bp trong module"""
        return [
            obj for name, obj in inspect.getmembers(module)
            if name.endswith('_bp')
        ]

    def generate_prefix_from_module(self, module):
        """Tạo URL prefix từ tên module: 'expense_routes' → '/expense'"""
        name = module.__name__.split('.')[-1]
        return '/' + name.replace('_routes', '')



