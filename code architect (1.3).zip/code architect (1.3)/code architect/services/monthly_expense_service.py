from decimal import Decimal
from models.database_models import db
from monthly_expense_data import MonthlyExpenseData
from models.database_models import MonthlyExpense
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime

class MonthlyExpenseService:
    def __init__(self, expense_repository):
        self.expense_repository = expense_repository
    
    def get_all_monthly_expenses(self, user_id: int) -> list:
        # Lấy dữ liệu thô từ Repository
        raw_expenses_data = self.expense_repository.get_all_monthly_expenses_by_user_id(user_id)
        return raw_expenses_data
    def get_monthly_expense_record(self, data: MonthlyExpenseData):
        return self.expense_repository.get_monthly_expense_record(data)
    # def get_monthly_expense_record(self, user_id: int, year: int, month: int):
    #     return self.expense_repository.get_monthly_expense_record(user_id, year, month)
    def update_monthly_expense(self, data: MonthlyExpenseData):
        try:
            expense = self.expense_repository.get_monthly_expense_record(data)
            if not expense:
                return ValueError("Chi tiêu tháng không tồn tại.")
            
            if data.target_value is not None:
                expense.target_value = Decimal(str(data.target_value)) 
                
            # Cập nhật total_amount nếu có trong data
            if data.total_amount is not None:
                expense.total_amount = Decimal(str(data.total_amount))

            db.session.commit()
            return expense
        except Exception as e:
            db.session.rollback()
            return RuntimeError(f"Lỗi: {str(e)}") 
    
    # def update_monthly_expense(self, user_id: int, year: int, month: int, 
    #                         total_amount: float = None, target_value: float = None):
    #     try:
    #         expense = self.expense_repository.get_monthly_expense_record(user_id, year, month)
    #         if not expense:
    #             return ValueError("Chi tiêu tháng không tồn tại.")

    #         if target_value is not None:
    #             expense.target_value = Decimal(str(target_value)) 
            
    #         if total_amount is not None:
    #             expense.total_amount = Decimal(str(total_amount))

    #         db.session.commit()
    #         return expense
    #     except Exception as e:
    #         db.session.rollback()
    #         return RuntimeError(f"Lỗi: {str(e)}") 
        

    # def update_monthly_expense(self, user_id: int, year: int, month: int, 
    #                         total_amount: float = None, target_value: float = None):
    #     try:
    #         expense = self.expense_repository.get_monthly_expense_record(user_id, year, month)
    #         if not expense:
    #             return ValueError("Chi tiêu tháng không tồn tại.")

    #         if target_value is not None:
    #             expense.target_value = Decimal(str(target_value)) 
            
    #         if total_amount is not None:
    #             expense.total_amount = Decimal(str(total_amount))

    #         db.session.commit()
    #         return expense
    #     except Exception as e:
    #         db.session.rollback()
    #         return RuntimeError(f"Lỗi: {str(e)}") 
        

    def update_monthly_expense_target(self, data: MonthlyExpenseData):
        try:
            updated = self.expense_repository.update_monthly_expense_target(
                data
            )
            if updated:
                db.session.commit()
                return True 
            else:
                raise ValueError(f"Không tìm thấy bản ghi chi tiêu tháng cho UserID={data.user_id}, Year={data.year}, Month={data.month}.")
        except Exception as e:
            db.session.rollback()
            raise RuntimeError(f"Lỗi hệ thống khi cập nhật mục tiêu chi tiêu tháng: {str(e)}")
    

    def create_expense(self, data: MonthlyExpenseData):
        record = self.expense_repository.add_monthly_expense(data)
        return record

    # THÊM HÀM XÓA NGƯỜI DÙNG Ở ĐÂY
    def delete_user_by_id(self, user_id: int):
        """
        Xóa tất cả dữ liệu chi tiêu hàng tháng (monthly_expense) của một người dùng dựa trên ID.
        """
        try:
            # Lọc các bản ghi trong bảng monthly_expense có user_id khớp với ID đã cung cấp
            # Giả sử bạn có model MonthlyExpense đã được định nghĩa.
            
            deleted_count = db.session.query(MonthlyExpense).filter(
                MonthlyExpense.user_id == user_id
            ).delete(synchronize_session=False) # Sử dụng xóa hàng loạt

            db.session.commit()
            
            if deleted_count > 0:
                return True, f"Đã xóa thành công {deleted_count} dòng dữ liệu chi tiêu hàng tháng cho User {user_id}"
            else:
                return False, f"Không tìm thấy dữ liệu chi tiêu hàng tháng nào cho User {user_id}"

        except SQLAlchemyError as e:
            db.session.rollback()
            return False, f"Lỗi cơ sở dữ liệu khi xóa dữ liệu chi tiêu: {str(e)}"
        except Exception as e:
            db.session.rollback()
            return False, f"Lỗi không mong muốn: {str(e)}"
    
    def delete_monthly_expenses_by_user_year_month(self, data: MonthlyExpenseData):
        """
        Xóa dữ liệu chi tiêu hàng tháng cụ thể dựa trên user_id, năm và tháng.
        """
        try:
            # Lọc các bản ghi trong bảng monthly_expense theo user_id, year và month
            deleted_count = db.session.query(MonthlyExpense).filter(
                MonthlyExpense.user_id == data.user_id,
                MonthlyExpense.year == data.year,
                MonthlyExpense.month == data.month
            ).delete(synchronize_session=False)

            db.session.commit()

            if deleted_count == 0:
                return True, 0, f"Không tìm thấy dữ liệu chi tiêu hàng tháng cho User {data.user_id} vào {data.month}/{data.year}."
            else:
                return True, deleted_count, f"Đã xóa thành công {deleted_count} dòng dữ liệu chi tiêu hàng tháng cho User {data.user_id} vào {data.month}/{data.year}."

        except SQLAlchemyError as e:
            db.session.rollback()
            return False, 0, f"Lỗi cơ sở dữ liệu: {str(e)}"
        except Exception as e:
            db.session.rollback()
            return False, 0, f"Lỗi không mong muốn: {str(e)}"
        
    # def delete_expenses_by_user_and_date(self, user_id: int, date_str: str):
    #     try:
    #         date_to_delete = datetime.strptime(date_str, '%Y-%m-%d').date()
    #         # Lọc các bản ghi theo user_id và ngày (giả sử bạn có model Expense)
    #         # db.cast(Expense.date, db.Date) giúp so sánh chỉ phần ngày của cột datetime
    #         deleted_count = db.session.query(Expense).filter(
    #             Expense.user_id == user_id,
    #             db.cast(Expense.date, db.Date) == date_to_delete
    #         ).delete(synchronize_session=False)

    #         db.session.commit()

    #         if deleted_count == 0:
    #             return True, 0, "Không tìm thấy chi tiêu nào để xóa."
    #         else:
    #             return True, deleted_count, f"Đã xóa thành công {deleted_count} dòng dữ liệu cho User {user_id} vào ngày {date_str}."

    # except ValueError:
    #     db.session.rollback()
    #     return False, 0, "Ngày không hợp lệ. Vui lòng sử dụng định dạng YYYY-MM-DD."
    # except SQLAlchemyError as e:
    #     db.session.rollback()
    #     return False, 0, f"Lỗi cơ sở dữ liệu: {str(e)}"
    # except Exception as e:
    #     db.session.rollback()
    #     return False, 0, f"Lỗi không mong muốn: {str(e)}"

    #     except ValueError:
    #         db.session.rollback()
    #         return False, 0, "Ngày không hợp lệ. Vui lòng sử dụng định dạng YYYY-MM-DD."
    #     except SQLAlchemyError as e:
    #         db.session.rollback()
    #         return False, 0, f"Lỗi cơ sở dữ liệu: {str(e)}"
    #     except Exception as e:
    #         db.session.rollback()
    #         return False, 0, f"Lỗi không mong muốn: {str(e)}"

    # def create_expense(self, user_id: int, year: int, month: int, total_amount: float, target_value: float):
    #     record = self.expense_repository.add_monthly_expense(user_id, year, month, total_amount, target_value)
    #     return record
    
    # def create_expense(self, user_id: int, year: int, month: int, target_value: float, total_amount: float):
    #     record = self.expense_repository.add_monthly_expense(user_id, year, month, target_value, total_amount)
    #     return record
    

