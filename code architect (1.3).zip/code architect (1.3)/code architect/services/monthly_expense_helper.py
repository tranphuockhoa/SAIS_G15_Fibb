from datetime import datetime


class MonthlyExpenseHelper:
    def __init__(self, monthly_expense_repository):
        """
        Khởi tạo MonthlyExpenseHelper với một đối tượng repository.
        """
        self.monthly_expense_repository = monthly_expense_repository

    def get_current_and_previous_month_records(self,user_id: int):
        """Lấy bản ghi của tháng hiện tại và tháng trước."""
        now = datetime.now()
        current_year = now.year
        current_month = now.month
        previous_year = now.year if now.month > 1 else now.year - 1
        previous_month = now.month - 1 if now.month > 1 else 12
        
        current_record = self.monthly_expense_repository.get_monthly_record(user_id, current_year, current_month)
        previous_record = self.monthly_expense_repository.get_monthly_record(user_id, previous_year, previous_month)
        
        return current_record, previous_record
    @staticmethod
    def get_record_value(record):
        return float(record.total_amount) if record else 0
