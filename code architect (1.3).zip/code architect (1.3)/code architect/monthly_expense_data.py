from pydantic import BaseModel, Field
from decimal import Decimal
from typing import Optional

class MonthlyExpenseData(BaseModel):
    user_id: int
    year: int
    month: int
    total_amount: Optional[Decimal] = None
    target_value: Optional[Decimal] = None