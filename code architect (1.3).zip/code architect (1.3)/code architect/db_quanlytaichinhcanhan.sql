/*
 Navicat Premium Data Transfer

 Source Server         : DB_QuanLyTaiChinhCaNhan
 Source Server Type    : MySQL
 Source Server Version : 90100 (9.1.0)
 Source Host           : localhost:3306
 Source Schema         : db_quanlytaichinhcanhan

 Target Server Type    : MySQL
 Target Server Version : 90100 (9.1.0)
 File Encoding         : 65001

 Date: 02/07/2025 14:01:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, 'Ăn uống');
INSERT INTO `category` VALUES (2, 'Di chuyển');
INSERT INTO `category` VALUES (4, 'Giải trí');
INSERT INTO `category` VALUES (7, 'Giáo dục');
INSERT INTO `category` VALUES (5, 'Hóa đơn');
INSERT INTO `category` VALUES (10, 'Khác');
INSERT INTO `category` VALUES (3, 'Mua sắm');
INSERT INTO `category` VALUES (8, 'Nhà ở');
INSERT INTO `category` VALUES (9, 'Tiết kiệm');
INSERT INTO `category` VALUES (6, 'Y tế');

-- ----------------------------
-- Table structure for expense
-- ----------------------------
DROP TABLE IF EXISTS `expense`;
CREATE TABLE `expense`  (
  `expense_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `amount` decimal(10, 2) NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`expense_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of expense
-- ----------------------------
INSERT INTO `expense` VALUES (1, 101, 50000.00, 1, 'Mua sắm tạp hóa', '2025-06-20 10:30:00');
INSERT INTO `expense` VALUES (2, 102, 120000.50, 2, 'Ăn trưa với bạn bè', '2025-06-21 13:00:00');
INSERT INTO `expense` VALUES (3, 101, 75000.00, 3, 'Phí đi lại', '2025-06-21 08:45:00');
INSERT INTO `expense` VALUES (4, 103, 250000.00, 4, 'Hóa đơn tiền điện', '2025-06-22 15:00:00');
INSERT INTO `expense` VALUES (5, 102, 30000.00, 1, 'Mua cà phê', '2025-06-22 09:15:00');
INSERT INTO `expense` VALUES (6, 104, 180000.75, 2, 'Ăn tối tại nhà hàng', '2025-06-23 19:30:00');
INSERT INTO `expense` VALUES (7, 103, 40000.00, 3, 'Đổ xăng', '2025-06-23 11:00:00');
INSERT INTO `expense` VALUES (8, 105, 1000000.00, 5, 'Thuê nhà tháng 6', '2025-06-24 09:00:00');
INSERT INTO `expense` VALUES (9, 104, 90000.00, 1, 'Mua đồ dùng cá nhân', '2025-06-24 14:00:00');
INSERT INTO `expense` VALUES (10, 105, 60000.00, 3, 'Phí gửi xe', '2025-06-25 10:00:00');
INSERT INTO `expense` VALUES (11, 102, 50000.00, 1, 'Mua sắm tạp hóa', '2025-06-20 00:00:00');
INSERT INTO `expense` VALUES (12, 102, 50000.00, 1, 'Mua sắm tạp hóa', '2025-06-20 00:00:00');
INSERT INTO `expense` VALUES (13, 102, 50000.00, 1, 'Mua sắm tạp hóa', '2025-06-20 00:00:00');
INSERT INTO `expense` VALUES (14, 102, 50000.00, 1, 'Mua sắm tạp hóa', '2025-06-20 00:00:00');
INSERT INTO `expense` VALUES (15, 102, 50000.00, 1, 'Mua sắm tạp hóa', '2025-06-20 00:00:00');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 103 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (102, 'Minh');

SET FOREIGN_KEY_CHECKS = 1;
