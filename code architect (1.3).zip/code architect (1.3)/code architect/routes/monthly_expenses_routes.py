from flask import Blueprint, request, jsonify, make_response 
# Repositories
from repositories.monthly_expense_repository import MonthlyExpenseRepository

# Utils
from utils.request_parser import RequestParser

# Services
from services.monthly_expense_helper import MonthlyExpenseHelper
from services.monthly_performance_analysis_service import MonthlyPerformanceAnalysisService
from services.monthly_expense_service import MonthlyExpenseService 
# Schemas
from schemas import MonthlyExpenseSchema # Ví dụ import

#data
from monthly_expense_data import MonthlyExpenseData

monthly_expense_repository = MonthlyExpenseRepository()

request_parser = RequestParser()
monthly_expense_helper = MonthlyExpenseHelper(monthly_expense_repository)
monthly_performance_analysis_service = MonthlyPerformanceAnalysisService(
        data_retriever_func=monthly_expense_helper.get_current_and_previous_month_records,
        value_getter_func= MonthlyExpenseHelper.get_record_value
    )


monthly_expense_schema = MonthlyExpenseSchema()

monthly_expenses_bp = Blueprint('monthly_expenses_routes', __name__)


@monthly_expenses_bp.route('/api/<int:user_id>', methods=['GET'])
def get_monthly_expenses_endpoint(user_id):
    try:
        user_id = int(user_id)
    except ValueError:
        return make_response(jsonify({
            "status": "error",
            "message": "User ID không hợp lệ. Vui lòng cung cấp một số nguyên."
        }), 400)    

    monthly_expense_service = MonthlyExpenseService(monthly_expense_repository)
    monthly_expenses_data = monthly_expense_service.get_all_monthly_expenses(user_id)

    if not monthly_expenses_data:
        return make_response(jsonify({
                "status": "success",
                "message": "Không tìm thấy chi tiêu hàng tháng nào cho người dùng này.",
                "data": [] # Trả về mảng rỗng trong trường hợp này
            }), 200) 
    

    serialized_data = monthly_expense_schema.dump(monthly_expenses_data, many=True)

    return serialized_data


@monthly_expenses_bp.route('/<int:user_id>', methods=['POST'])
def index(user_id):
    data = request.get_json()
    month = data.get('month')
    year = data.get('year')
    amount = data.get('total_amount')
    value = data.get('target_value')
    try:
        value = float(value)
        data = MonthlyExpenseData(user_id=user_id, year=year, month=month, target_value=value)
        MonthlyExpenseService(monthly_expense_repository).create_expense(data)
        return jsonify({'status': 'success', 'message': 'Record created successfully'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@monthly_expenses_bp.route('/<int:user_id>/<int:year>/<int:month>', methods=['GET'])
def get_monthly_expense(user_id, year, month):
    """
    Truy xuất bản ghi chi tiêu hàng tháng cho một người dùng, năm và tháng cụ thể.
    """
    data = MonthlyExpenseData(user_id=user_id, year=year, month=month)
    monthly_expense_record = MonthlyExpenseService(monthly_expense_repository).get_monthly_expense_record(data)

    if not monthly_expense_record:
        return jsonify({"message": "Không tìm thấy bản ghi chi tiêu tháng nào."}), 404

    return jsonify({
        "message": "Truy xuất chi tiêu tháng thành công.",
        "expense": monthly_expense_schema.dump(monthly_expense_record)
    }), 200


@monthly_expenses_bp.route('/<int:user_id>/<int:year>/<int:month>', methods=['PUT'])
def update_monthly_expense(user_id, year, month):
    data = request.get_json()
    amount = data.get('total_amount')
    value = data.get('target_value')

    data = MonthlyExpenseData(user_id=user_id, year=year, month=month, total_amount=amount, target_value=value)
    updated_expense = MonthlyExpenseService(monthly_expense_repository).update_monthly_expense(data)
    if not updated_expense:
        return jsonify({"message": "Không tìm thấy chi tiêu tháng nào."}), 404

    return jsonify({
        "message": "Cập nhật chi tiêu tháng thành công.",
        "expense": monthly_expense_schema.dump(updated_expense)
    }), 200


@monthly_expenses_bp.route('/target/<int:user_id>', methods=['PATCH'])
def set_target(user_id):
    data = request.get_json()

    month = data['month']
    year = data['year']
    target_value = data['target_value']
    # target_value_float = float(data['target_value']) # Chuyển đổi trực tiếp

    try:
        data = MonthlyExpenseData(user_id=user_id, year=year, month=month, target_value=target_value)
        MonthlyExpenseService(monthly_expense_repository).update_monthly_expense_target(data)
        
        return jsonify({
            'message': f'Đã cập nhật mục tiêu chi tiêu cho UserID={user_id}, Tháng={month}, Năm={year} thành công.',
            'user_id': user_id,
            'month': month,
            'target_value': target_value
        }), 200

    except Exception as e:
        return jsonify({
            'error': f'Đã xảy ra lỗi: {str(e)}'
            }), 500




@monthly_expenses_bp.route('/api/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    """
    Endpoint DELETE /<user_id> để xóa người dùng.
    """
    # Gọi hàm service để thực hiện logic xóa người dùng
    success, message = MonthlyExpenseService(monthly_expense_repository).delete_user_by_id(user_id)

    if success:
        # Nếu service trả về thành công, trả về 200 OK
        return jsonify({
            "status": "success",
            "message": message
        }), 200
    else:
        # Xử lý lỗi
        if "User not found" in message:
            return jsonify({
                "status": "error",
                "message": message
            }), 404 # Trả về 404 Not Found nếu người dùng không tồn tại
        else:
            return jsonify({
                "status": "error",
                "message": message
            }), 500 # Trả về 500 Internal Server Error cho các lỗi khác

@monthly_expenses_bp.route('api/<int:user_id>/<int:year>/<int:month>', methods=['DELETE'])
def delete_monthly_expenses(user_id, year, month):
    """
    Endpoint xóa dữ liệu chi tiêu hàng tháng cụ thể dựa trên user_id, năm và tháng.
    """
    data = MonthlyExpenseData(user_id=user_id, year=year, month=month)
    success, deleted_count, message = MonthlyExpenseService(monthly_expense_repository).delete_monthly_expenses_by_user_year_month(data)

    if success:
        # Trả về 200 nếu xóa thành công, hoặc 404 nếu không tìm thấy dữ liệu để xóa
        return jsonify({
            "status": "success",
            "message": message,
            "deleted_count": deleted_count
        }), 200 if deleted_count > 0 else 404
    else:
        # Trả về lỗi 400 hoặc 500
        return jsonify({
            "status": "error",
            "message": message
        }), 400

