from flask import Blueprint, request, jsonify
from models.database_models import db, User # Import db và User từ models

user_bp = Blueprint('user_routes', __name__)

@user_bp.route('/', methods=['POST'])
def create_user():
    """
    Tạo một người dùng mới.
    Yêu cầu: JSON body với trường 'username'.
    Phản hồi: Thông báo thành công và thông tin người dùng mới hoặc lỗi.
    """
    data = request.get_json()
    if not data or 'username' not in data:
        return jsonify({"error": "Thiếu trường bắt buộc: 'username'"}), 400

    username = data['username'].strip()
    if not username:
        return jsonify({"error": "Tên người dùng không được để trống"}), 400

    existing_user = User.query.filter_by(username=username).first()
    if existing_user:
        return jsonify({"error": f"Người dùng '{username}' đã tồn tại."}), 409

    new_user = User(username=username)
    db.session.add(new_user)
    db.session.commit()

    return jsonify({"message": "Người dùng đã được tạo thành công", "user": {"id": new_user.id, "username": new_user.username}}), 201

@user_bp.route('/', methods=['GET'])
def get_all_users():
    """
    Lấy danh sách tất cả người dùng.
    Phản hồi: Danh sách các đối tượng người dùng.
    """
    users = User.query.all()
    return jsonify([{"id": user.id, "username": user.username} for user in users]), 200