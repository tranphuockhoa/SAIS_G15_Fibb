from decimal import Decimal
from models.database_models import db


class MonthlyExpenseService:
    def __init__(self, expense_repository):
        self.expense_repository = expense_repository
    
    def get_all_monthly_expenses(self, user_id: int) -> list:
        # Lấy dữ liệu thô từ Repository
        raw_expenses_data = self.expense_repository.get_all_monthly_expenses_by_user_id(user_id)
        return raw_expenses_data
 
    def update_monthly_expense(self, user_id: int, year: int, month: int, update_data: dict):
        try:
            expense = self.expense_repository.get_monthly_expense_record(user_id, year, month)
            if not expense:
                return ValueError("Chi tiêu tháng không tồn tại.")

            if 'total_amount' in update_data:
                expense.total_amount = Decimal(update_data['total_amount'])
            if 'target_value' in update_data:
                expense.target_value = Decimal(update_data['target_value'])

            db.session.commit()
            return expense
        except Exception as e:
            db.session.rollback()
            return RuntimeError(f"Lỗi hệ thống khi cập nhật chi tiêu tháng: {str(e)}")
    
    def update_monthly_expense_target(self, user_id: int, year: int, month: int, target_value: float):
        try:
            updated = self.expense_repository.update_monthly_expense_target(
                user_id, year, month, target_value
            )
            
            if updated:
                db.session.commit()
                return True 
            else:
                raise ValueError(f"Không tìm thấy bản ghi chi tiêu tháng cho UserID={user_id}, Year={year}, Month={month}.")
        except Exception as e:
            db.session.rollback()
            raise RuntimeError(f"Lỗi hệ thống khi cập nhật mục tiêu chi tiêu tháng: {str(e)}")
        

    def create_expense(self, user_id: int, year: int, month: int, value: float):
        record = self.expense_repository.add_monthly_expense(user_id, year, month, value)
        return record
    

