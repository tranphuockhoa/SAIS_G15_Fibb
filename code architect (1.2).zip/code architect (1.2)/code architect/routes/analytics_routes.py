from flask import Blueprint, request, jsonify, make_response 
# Repositories
from repositories.monthly_expense_repository import MonthlyExpenseRepository

# Utils
from utils.request_parser import RequestParser

# Services
from services.monthly_expense_helper import MonthlyExpenseHelper
from services.monthly_performance_analysis_service import MonthlyPerformanceAnalysisService
from services.monthly_expense_service import MonthlyExpenseService 
from services.growth_analyzer import GrowthAnalyzer
# Schemas
from schemas import MonthlyExpenseSchema # Ví dụ import


from decimal import Decimal

monthly_expense_repository = MonthlyExpenseRepository()

request_parser = RequestParser()
monthly_expense_helper = MonthlyExpenseHelper(monthly_expense_repository)
monthly_performance_analysis_service = MonthlyPerformanceAnalysisService(
        data_retriever_func=monthly_expense_helper.get_current_and_previous_month_records,
        value_getter_func= MonthlyExpenseHelper.get_record_value
    )

monthly_expense_schema = MonthlyExpenseSchema()

analytics_bp = Blueprint('analytics_routes', __name__)


@analytics_bp.route('/api/monthly-expenses/<int:user_id>', methods=['GET'])
def get_monthly_expenses_endpoint(user_id):
    try:
        user_id = int(user_id)
    except ValueError:
        return make_response(jsonify({
            "status": "error",
            "message": "User ID không hợp lệ. Vui lòng cung cấp một số nguyên."
        }), 400)    

    monthly_expense_service = MonthlyExpenseService(monthly_expense_repository)
    monthly_expenses_data = monthly_expense_service.get_all_monthly_expenses(user_id)

    if not monthly_expenses_data:
        return make_response(jsonify({
                "status": "success",
                "message": "Không tìm thấy chi tiêu hàng tháng nào cho người dùng này.",
                "data": [] # Trả về mảng rỗng trong trường hợp này
            }), 200) 
    

    serialized_data = monthly_expense_schema.dump(monthly_expenses_data, many=True)

    return serialized_data


@analytics_bp.route('/monthly-expenses/<int:user_id>', methods=['POST'])
def index(user_id):
    data = request.get_json()
    month = data.get('month')
    year = data.get('year')
    value = data.get('target_value')
    try:
        value = float(value)
        MonthlyExpenseService(monthly_expense_repository).create_expense(user_id, year, month, value)
        return jsonify({'status': 'success', 'message': 'Record created successfully'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@analytics_bp.route('/monthly_expenses/<int:user_id>/<int:year>/<int:month>', methods=['PUT'])
def update_monthly_expense(user_id, year, month):
    data = request.get_json()

    updated_expense = MonthlyExpenseService(monthly_expense_repository).update_monthly_expense(user_id, year, month, data)
    if not updated_expense:
        return jsonify({"message": "Không tìm thấy chi tiêu tháng nào."}), 404

    return jsonify({
        "message": "Cập nhật chi tiêu tháng thành công.",
        "expense": monthly_expense_schema.dump(updated_expense)
    }), 200


@analytics_bp.route('/monthly_expenses/target/<int:user_id>', methods=['PATCH'])
def set_target(user_id):
    data = request.get_json()

    month = data['month']
    year = data['year']
    target_value_float = float(data['target_value']) # Chuyển đổi trực tiếp

    try:
        MonthlyExpenseService(monthly_expense_repository).update_monthly_expense_target(user_id, year, month, target_value_float)
        
        return jsonify({
            'message': f'Đã cập nhật mục tiêu chi tiêu cho UserID={user_id}, Tháng={month} thành công.',
            'user_id': user_id,
            'month': month,
            'target_value': target_value_float
        }), 200


    except Exception as e:
        return jsonify({
            'error': f'Đã xảy ra lỗi: {str(e)}'
            }), 500


# @analytics_bp.route('/api/data/<int:user_id>', methods=['GET'])
# def api_data(user_id):
#     try:
#         data_list = monthly_expense_repository.get_monthly_data(user_id) 
        
#         # Làm giàu dữ liệu với pct_change và recommendation
#         enriched_data = GrowthAnalyzer().add_growth_metrics(data_list) 
        
#         return jsonify({"status": "success", "data": enriched_data}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500
    

# @analytics_bp.route('/', methods=['GET'])
# def get_monthly_expenses():
#     try:
#         # Lấy user_id từ query parameters (ví dụ: /api/data?user_id=1)
#         # request.args là một MultiDict chứa các tham số truy vấn URL
#         user_id_str = request.args.get('user_id')

#         if not user_id_str:
#             return jsonify({'error': 'Missing user_id parameter'}), 400

#         try:
#             user_id = int(user_id_str)
#         except ValueError:
#             return jsonify({'error': 'Invalid user_id format. Must be an integer.'}), 400

#         data = MonthlyExpenseRepository().get_monthly_data(user_id)
#         return jsonify(data), 200

#     except Exception as e:
#         # Ghi log lỗi để dễ dàng debug hơn trong môi trường production
#         # app.logger.error(f"Error in api_data: {e}")
#         return jsonify({'error': 'An internal server error occurred: ' + str(e)}), 500
    

# @analytics_bp.route('/monthly-summary/<int:user_id>', methods=['GET'])
# def get_monthly_summary(user_id):
#     try:
#         summary = monthly_performance_analysis_service.get_monthly_performance_summary(user_id)
#         return jsonify({
#             'status': 'success',
#             'data': summary
#         }), 200
#     except Exception as e:
#         return jsonify({'error': f'An internal server error occurred: {str(e)}'}), 500




# @analytics_bp.route('/api/target', methods=['POST'])
# def set_target():
#     monthly_expense_repository = MonthlyExpenseRepository()
#     request_parser = RequestParser(request)
#     try:
#         # 1. Phân tích dữ liệu từ request
#         user_id, month_str, target_value = request_parser.parse_target_request_data()

#         # 2. Trích xuất năm và tháng
#         year, month = request_parser.extract_year_and_month(month_str)

#         # 3. Cập nhật mục tiêu trong cơ sở dữ liệu
#         if monthly_expense_repository._update_monthly_target(user_id, year, month, target_value):
#             return jsonify({'message': 'Target updated successfully'}), 200
#         else:
#             return jsonify({'error': 'Month not found for user'}), 404

#     except ValueError as ve:
#         # Xử lý lỗi liên quan đến định dạng dữ liệu đầu vào
#         return jsonify({'error': str(ve)}), 400
#     except Exception as e:
#         # Xử lý các lỗi chung khác (ví dụ: lỗi DB)
#         # Tùy thuộc vào ứng dụng, bạn có thể muốn ghi log lỗi 'e' ở đây
#         return jsonify({'error': 'An internal server error occurred: ' + str(e)}), 500