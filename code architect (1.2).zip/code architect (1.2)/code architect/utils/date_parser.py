from datetime import datetime, UTC

def parse_date(date_str):
    if not date_str:
        # Nếu date_str rỗng hoặc None, trả về ngày hiện tại UTC
        return datetime.now(UTC).date(), None, None

    # Danh sách các định dạng ngày/thời gian mà bạn muốn hỗ trợ
    # Thêm định dạng ISO 8601 đầy đủ (có 'T' và thời gian)
    date_formats = [
        '%Y-%m-%dT%H:%M:%S',  # YYYY-MM-DDTHH:MM:SS (ví dụ: 2025-06-20T10:30:00)
    ]

    for fmt in date_formats:
        try:
            # datetime.strptime sẽ trả về một đối tượng datetime
            parsed_datetime = datetime.strptime(date_str, fmt)
            # Sau đó, lấy chỉ phần ngày (.date())
            return parsed_datetime.date(), None, None
        except ValueError:
            pass # Thử định dạng tiếp theo nếu không khớp

    # Nếu không khớp với bất kỳ định dạng nào
    return None, "Định dạng ngày không hợp lệ. Vui lòng sử dụng sử dụng định dạng YYYY-MM-DDTHH:MM:SS.", 400