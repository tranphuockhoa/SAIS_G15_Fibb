import pandas as pd

# Hàm để nhập dữ liệu từ người dùng
def nhap_du_lieu():
    thang_truoc = input("Nhập dữ liệu tháng trước (cách nhau bằng dấu phẩy): ")
    thang_sau = input("Nhập dữ liệu tháng sau (cách nhau bằng dấu phẩy): ")
    
    # Chuyển đổi dữ liệu thành danh sách
    du_lieu_thang_truoc = list(map(float, thang_truoc.split(',')))
    du_lieu_thang_sau = list(map(float, thang_sau.split(',')))
    
    return du_lieu_thang_truoc, du_lieu_thang_sau

# Hàm để so sánh dữ liệu và đưa ra đề xuất
def so_sanh_du_lieu(du_lieu_thang_truoc, du_lieu_thang_sau):
    df = pd.DataFrame({
        'Thang Truoc': du_lieu_thang_truoc,
        'Thang Sau': du_lieu_thang_sau
    })
    
    # Tính toán sự thay đổi
    df['Thay Doi'] = df['Thang Sau'] - df['Thang Truoc']
    
    # Đưa ra đề xuất
    for index, row in df.iterrows():
        if row['Thay Doi'] > 0:
            print(f"Đề xuất: Tăng cường hoạt động cho mục {index + 1}.")
        elif row['Thay Doi'] < 0:
            print(f"Đề xuất: Giảm bớt hoạt động cho mục {index + 1}.")
        else:
            print(f"Đề xuất: Giữ nguyên hoạt động cho mục {index + 1}.")

# Chương trình chính
def main():
    du_lieu_thang_truoc, du_lieu_thang_sau = nhap_du_lieu()
    so_sanh_du_lieu(du_lieu_thang_truoc, du_lieu_thang_sau)

if __name__ == "__main__":
    main()
