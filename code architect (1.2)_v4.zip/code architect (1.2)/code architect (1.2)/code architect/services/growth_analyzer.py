from models.database_models import db, User 
from sqlalchemy.exc import SQLAlchemyError
from models.database_models import db, Expense,MonthlyExpense 
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime

class GrowthAnalyzer:
    def compute_recommendation(self, pct):
        if pct is None:
            return 'No previous data'
        if pct > 10:
            return 'Excellent growth – consider expanding'
        if pct > 0:
            return 'Positive trend – maintain course'
        if pct == 0:
            return 'Stable – no action needed'
        if pct >= -10:
            return 'Slight dip – investigate'
        return 'Significant drop – urgent review'

    def __calculate_growth_metrics(self, current_amount, previous_amount):
        """
        Tính toán phần trăm thay đổi và khuyến nghị cho một cặp giá trị.
        Trả về một dictionary chứa 'pct_change' và 'recommendation'.
        """
        if previous_amount is None or previous_amount == 0:
            pct = None
        else:
            pct = (current_amount - previous_amount) / previous_amount * 100
            pct = round(pct, 2)

        recommendation = self.compute_recommendation(pct)
        return {'pct_change': pct, 'recommendation': recommendation}
    
    def add_growth_metrics(self, data_list):
        """
        Thêm các chỉ số tăng trưởng (phần trăm thay đổi và khuyến nghị) vào mỗi bản ghi trong danh sách.
        Trả về danh sách đã được bổ sung.
        """
        processed_data = []
        for i, rec in enumerate(data_list):
            new_rec = rec.copy()  # Tạo bản sao để tránh sửa đổi bản gốc trực tiếp

            if i == 0:
                metrics = self.__calculate_growth_metrics(new_rec['total_amount'], None)
            else:
                prev_amount = data_list[i - 1]['total_amount']
                metrics = self.__calculate_growth_metrics(new_rec['total_amount'], prev_amount)

            new_rec.update(metrics)
            processed_data.append(new_rec)
        return processed_data
    
# Sửa đổi HÀM XÓA:
def delete_user_by_id(user_id: int):
    """
    Xóa tất cả dữ liệu chi tiêu hàng tháng (monthly_expense) của một người dùng dựa trên ID.
    """
    try:
        # Lọc các bản ghi trong bảng monthly_expense có user_id khớp với ID đã cung cấp
        # Giả sử bạn có model MonthlyExpense đã được định nghĩa.
        
        deleted_count = db.session.query(MonthlyExpense).filter(
            MonthlyExpense.user_id == user_id
        ).delete(synchronize_session=False) # Sử dụng xóa hàng loạt

        db.session.commit()
        
        if deleted_count > 0:
            return True, f"Đã xóa thành công {deleted_count} dòng dữ liệu chi tiêu hàng tháng cho User {user_id}"
        else:
            return False, f"Không tìm thấy dữ liệu chi tiêu hàng tháng nào cho User {user_id}"

    except SQLAlchemyError as e:
        db.session.rollback()
        return False, f"Lỗi cơ sở dữ liệu khi xóa dữ liệu chi tiêu: {str(e)}"
    except Exception as e:
        db.session.rollback()
        return False, f"Lỗi không mong muốn: {str(e)}"
    
# Xóa hàm delete_expenses_by_user_and_date cũ và thay thế bằng hàm mới:
def delete_monthly_expenses_by_user_year_month(user_id: int, year: int, month: int):
    """
    Xóa dữ liệu chi tiêu hàng tháng cụ thể dựa trên user_id, năm và tháng.
    """
    try:
        # Lọc các bản ghi trong bảng monthly_expense theo user_id, year và month
        deleted_count = db.session.query(MonthlyExpense).filter(
            MonthlyExpense.user_id == user_id,
            MonthlyExpense.year == year,
            MonthlyExpense.month == month
        ).delete(synchronize_session=False)

        db.session.commit()

        if deleted_count == 0:
            return True, 0, f"Không tìm thấy dữ liệu chi tiêu hàng tháng cho User {user_id} vào {month}/{year}."
        else:
            return True, deleted_count, f"Đã xóa thành công {deleted_count} dòng dữ liệu chi tiêu hàng tháng cho User {user_id} vào {month}/{year}."

    except SQLAlchemyError as e:
        db.session.rollback()
        return False, 0, f"Lỗi cơ sở dữ liệu: {str(e)}"
    except Exception as e:
        db.session.rollback()
        return False, 0, f"Lỗi không mong muốn: {str(e)}"

    except ValueError:
        db.session.rollback()
        return False, 0, "Ngày không hợp lệ. Vui lòng sử dụng định dạng YYYY-MM-DD."
    except SQLAlchemyError as e:
        db.session.rollback()
        return False, 0, f"Lỗi cơ sở dữ liệu: {str(e)}"
    except Exception as e:
        db.session.rollback()
        return False, 0, f"Lỗi không mong muốn: {str(e)}"
