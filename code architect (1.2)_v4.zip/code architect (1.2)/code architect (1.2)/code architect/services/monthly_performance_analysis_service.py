from models.performance_summary import PerformanceSummary

class MonthlyPerformanceAnalysisService:
    def __init__(self, data_retriever_func, value_getter_func):
        self._get_records = data_retriever_func
        self._get_value = value_getter_func

    def __build_performance_summary(self, current_value, previous_value, target_value):
        temp_summary = PerformanceSummary(current_value, previous_value, target_value)
        return temp_summary.to_dict()

    def get_monthly_performance_summary(self, user_id):
        """
        Tổng hợp dữ liệu hiệu suất tài chính cho tháng hiện tại và tháng trước
        của một người dùng cụ thể, bao gồm so sánh với mục tiêu và giữa các tháng.
        """
        # 1. TRÁCH NHIỆM: Lấy dữ liệu thô (gọi từ DAL)
        current_record, previous_record = self._get_records(user_id)
        
        if not current_record:
            return PerformanceSummary(None, None, None).to_dict()

        current_value = self._get_value(current_record)
        previous_value = self._get_value(previous_record)
        target_value = current_record.target_value if hasattr(current_record, 'target_value') else None

        enriched_summary = self.__build_performance_summary(current_value, previous_value, target_value)
        return enriched_summary
    



