from decimal import Decimal
from models.database_models import db,Expense, MonthlyExpense
from sqlalchemy import func, extract # Import func và extract từ SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime


class MonthlyExpenseService:
    def __init__(self, expense_repository):
        self.expense_repository = expense_repository
    
    def get_all_monthly_expenses(self, user_id: int) -> list:
        # Lấy dữ liệu thô từ Repository
        raw_expenses_data = self.expense_repository.get_all_monthly_expenses_by_user_id(user_id)
        return raw_expenses_data
 
    def update_monthly_expense(self, user_id: int, year: int, month: int, update_data: dict):
        try:
            expense = self.expense_repository.get_monthly_expense_record(user_id, year, month)
            if not expense:
                return ValueError("Chi tiêu tháng không tồn tại.")

            if 'total_amount' in update_data:
                expense.total_amount = Decimal(update_data['total_amount'])
            if 'target_value' in update_data:
                expense.target_value = Decimal(update_data['target_value'])

            db.session.commit()
            return expense
        except Exception as e:
            db.session.rollback()
            return RuntimeError(f"Lỗi hệ thống khi cập nhật chi tiêu tháng: {str(e)}")
    
    def update_monthly_expense_target(self, user_id: int, year: int, month: int, target_value: float):
        try:
            updated = self.expense_repository.update_monthly_expense_target(
                user_id, year, month, target_value
            )
            
            if updated:
                db.session.commit()
                return True 
            else:
                raise ValueError(f"Không tìm thấy bản ghi chi tiêu tháng cho UserID={user_id}, Year={year}, Month={month}.")
        except Exception as e:
            db.session.rollback()
            raise RuntimeError(f"Lỗi hệ thống khi cập nhật mục tiêu chi tiêu tháng: {str(e)}")
        

    def create_expense(self, user_id: int, year: int, month: int, value: float):
        record = self.expense_repository.add_monthly_expense(user_id, year, month, value)
        return record
    
# Hàm service để tổng hợp và lưu dữ liệu chi tiêu hàng tháng
def aggregate_and_save_monthly_expenses():
    """
    Tổng hợp dữ liệu chi tiêu từ bảng 'expense' theo user_id, năm, tháng
    và cập nhật/chèn vào bảng 'monthly_expense'.
    """
    print("Đang bắt đầu tổng hợp dữ liệu chi tiêu hàng tháng...")
    try:
        # 1. Tổng hợp dữ liệu từ bảng expense
        # Nhóm theo user_id, năm (từ cột date), tháng (từ cột date)
        # và tính tổng amount
        monthly_sums = db.session.query(
            Expense.user_id,
            extract('year', Expense.date).label('year'),
            extract('month', Expense.date).label('month'),
            func.sum(Expense.amount).label('total_amount')
        ).group_by(
            Expense.user_id,
            extract('year', Expense.date),
            extract('month', Expense.date)
        ).all()

        # 2. Duyệt qua các kết quả tổng hợp và cập nhật/chèn vào MonthlyExpense
        for user_id, year, month, total_amount_float in monthly_sums:
            # Chuyển đổi total_amount sang Decimal để đảm bảo độ chính xác
            total_amount_decimal = Decimal(str(total_amount_float)).quantize(Decimal('0.01'))

            # Tìm bản ghi MonthlyExpense hiện có
            monthly_expense = MonthlyExpense.query.filter_by(
                user_id=user_id,
                year=int(year), # extract trả về float, cần chuyển sang int
                month=int(month) # extract trả về float, cần chuyển sang int
            ).first()

            if monthly_expense:
                # Nếu bản ghi đã tồn tại, cập nhật total_amount
                monthly_expense.total_amount = total_amount_decimal
                print(f"Cập nhật MonthlyExpense: User {user_id}, {int(month)}/{int(year)}, Tổng: {total_amount_decimal}")
            else:
                # Nếu chưa tồn tại, tạo bản ghi mới
                # Lưu ý: target_value sẽ được đặt mặc định nếu không được cung cấp
                new_monthly_expense = MonthlyExpense(
                    user_id=user_id,
                    year=int(year),
                    month=int(month),
                    total_amount=total_amount_decimal,
                    target_value=Decimal('0.00') # Đặt mặc định nếu không có giá trị target
                )
                db.session.add(new_monthly_expense)
                print(f"Thêm mới MonthlyExpense: User {user_id}, {int(month)}/{int(year)}, Tổng: {total_amount_decimal}")
        
        db.session.commit()
        print("Tổng hợp dữ liệu chi tiêu hàng tháng hoàn tất thành công.")

    except SQLAlchemyError as e:
        db.session.rollback()
        print(f"Lỗi cơ sở dữ liệu khi tổng hợp chi tiêu hàng tháng: {str(e)}")
    except Exception as e:
        db.session.rollback()
        print(f"Lỗi không mong muốn khi tổng hợp chi tiêu hàng tháng: {str(e)}")
    

