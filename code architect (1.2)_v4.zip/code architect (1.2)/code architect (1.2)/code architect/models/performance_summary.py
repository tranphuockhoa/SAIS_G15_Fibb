from utils.financial_analysis_utils import FinancialAnalysisUtils

class PerformanceSummary:
    """
    Đại diện cho một bản tóm tắt hiệu suất tài chính, bao gồm các giá trị hiện tại,
    trước đó và mục tiêu, cùng với các phép so sánh liên quan.
    """
    def __init__(self, current_value, previous_value, target_value):
        self.current_value = current_value
        self.previous_value = previous_value
        self.target_value = target_value

    def to_dict(self):
        """
        Chuyển đổi dữ liệu tóm tắt hiệu suất thành định dạng dictionary.
        """
        return {
            'current': {
                'value': self.current_value,
                'target': self.target_value,
                'comparison': FinancialAnalysisUtils.compare_with_target(self.current_value, self.target_value) if self.current_value is not None and self.target_value is not None else None
            },
            'previous': {
                'value': self.previous_value
            },
            'month_to_month': FinancialAnalysisUtils.compare_with_previous(self.current_value, self.previous_value) if self.current_value is not None and self.previous_value is not None else None
        }
    
