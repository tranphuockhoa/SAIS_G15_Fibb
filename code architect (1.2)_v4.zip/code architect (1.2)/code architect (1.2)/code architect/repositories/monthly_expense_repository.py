from models.database_models import db, MonthlyExpense
from decimal import Decimal


class MonthlyExpenseRepository:
    def add_monthly_expense(self,user_id: int, year: int, month: int, value: float) -> MonthlyExpense:
        """
        Tạo và lưu một bản ghi MonthlyExpense mới.
        Trả về object MonthlyExpense vừa tạo.
        """
        try:
            record = MonthlyExpense(
                user_id=user_id,
                year=year,
                month=month,
                total_amount=Decimal(value)
            )
            db.session.add(record)
            db.session.commit()
            return record
        except Exception as e:
            db.session.rollback()
            raise e
    
    def get_all_monthly_expenses_by_user_id(self, user_id: int) -> list:
        """
        Truy vấn tất cả bản ghi MonthlyExpense của user theo thứ tự tháng,
        rồi chuyển thành list of dict.
        """
        raw = MonthlyExpense.query.filter_by(user_id=user_id).order_by(MonthlyExpense.year, MonthlyExpense.month).all()
        return [record.to_dict() for record in raw]

    def __query_monthly_expense(self, user_id: int, year: int, month: int):
        """
        Phương thức nội bộ để chỉ thực hiện truy vấn cơ sở dữ liệu.
        """
        try:
            record = MonthlyExpense.query.filter_by(
                user_id=user_id,
                year=year,
                month=month
            ).first()
            
            return record
        except Exception as e:
            print(f"CRITICAL ERROR during DB query in _query_monthly_expense: {e}")
            return None
    
    def get_monthly_expense_record(self, user_id: int, year: int, month: int):
        """
        Truy vấn và trả về bản ghi MonthlyExpense theo user_id, year và month.
        """
        try:
            record = self.__query_monthly_expense(user_id, year, month)
        
            if record:
                print(f"SUCCESS: Record FOUND. Total Amount: {record.total_amount}")
                # Nếu có thuộc tính target_value, cũng in ra
                if hasattr(record, 'target_value'):
                    print(f"SUCCESS: Record Target Value: {record.target_value}")
            else:
                print(f"NOT FOUND: No record found for UserID={user_id}, Year={year}, Month={month}")
            
            print(f"--- DEBUG: Exiting get_monthly_record ---")
            return record
        except Exception as e:
            # Ghi log lỗi nghiêm trọng nếu có vấn đề với truy vấn DB
            print(f"CRITICAL ERROR in MonthlyExpenseRepository: {e}")
            # Trong môi trường thực, bạn nên dùng thư viện logging thay vì print
            return None

    
    def update_monthly_expense_target(self, user_id: int, year: int, month: int, target_value: float) -> bool:
        """
        Tìm kiếm và cập nhật giá trị mục tiêu cho bản ghi MonthlyExpense.
        """
        try:
            record = self.__query_monthly_expense(user_id, year, month)
            if record:
                record.target_value = target_value
                return True
            return False 
        except Exception as e:
            # Ghi log lỗi nghiêm trọng (sử dụng thư viện logging trong thực tế)
            print(f"CRITICAL ERROR in MonthlyExpenseRepository while updating target: {e}")
            raise