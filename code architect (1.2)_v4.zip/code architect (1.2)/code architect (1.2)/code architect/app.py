# app.py

import sys
import os

# Thêm thư mục gốc của ứng dụng vào sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

from flask import Flask, jsonify
from flask_marshmallow import Marshmallow
from models.database_models import db
ma = Marshmallow()

from RouteManager import RouteManager

# Import hàm tổng hợp từ services/monthly_expense_service.py
from services.monthly_expense_service import aggregate_and_save_monthly_expenses 

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:Kh123456%40@localhost/architecture'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

RouteManager(app)

if __name__ == '__main__':
    # Tạo bảng CSDL khi ứng dụng chạy lần đầu
    with app.app_context():
        db.create_all() # Đảm bảo các bảng đã được tạo

        # GỌI HÀM TỔNG HỢP DỮ LIỆU TẠI ĐÂY
        aggregate_and_save_monthly_expenses() 
        
    app.run(debug=True)