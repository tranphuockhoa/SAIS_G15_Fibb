import sys
import os
# Thêm thư mục gốc của ứng dụng (nơi chứa app.py) vào sys.path để Python 
# có thể tìm thấy các gói như 'routes' và 'services'
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)
from flask import Flask, jsonify
from flask_marshmallow import Marshmallow
from models.database_models import db
ma = Marshmallow()

# from routes.expenses_routes import expense_bp
# from routes.home_route import home_bp # Blueprint cho route home

from RouteManager import RouteManager

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:Kh123456%40@localhost/architecture'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:123456@localhost/DB_QuanLyTaiChinhCaNhan'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

RouteManager(app)

if __name__ == '__main__':
    # Tạo bảng CSDL khi ứng dụng chạy lần đầu
    with app.app_context():
        db.create_all()
    app.run(debug=True)