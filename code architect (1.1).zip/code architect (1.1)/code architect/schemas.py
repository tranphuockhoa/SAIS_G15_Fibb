from flask_marshmallow import Marshmallow
from marshmallow_sqlalchemy import SQLAlchemyAutoSchema
from models.database_models import MonthlyExpense, db
ma = Marshmallow()

class MonthlyExpenseSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = MonthlyExpense
        # RẤT QUAN TRỌNG: Chỉ định db.session cho SQLAlchemyAutoSchema
        sqla_session = db.session
        load_instance = True
        # Bạn có thể thêm các trường bạn muốn expose nếu không muốn tất cả
        fields = ("user_id", "year", "month", "total_amount", "target_value")

# class MonthlyExpenseSchema(ma.SQLAlchemyAutoSchema):
#     class Meta:
#         model = MonthlyExpense
#         load_instance = True