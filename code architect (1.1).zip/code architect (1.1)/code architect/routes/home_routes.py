from flask import Blueprint

# Tạo một Blueprint mới
home_bp = Blueprint('home', __name__)

@home_bp.route('/')
def home():
    """
    Route mặc định cho trang chủ API.
    """
    return "API quản lý chi tiêu và danh mục đang chạy!"
