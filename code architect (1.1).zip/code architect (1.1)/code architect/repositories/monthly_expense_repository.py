from models.database_models import db, MonthlyExpense
from decimal import Decimal

class MonthlyExpenseRepository:
    def add_monthly_expense(self,user_id: int, year: int, month: int, value: float) -> MonthlyExpense:
        """
        Tạo và lưu một bản ghi MonthlyExpense mới.
        Trả về object MonthlyExpense vừa tạo.
        """
        try:
            record = MonthlyExpense(
                user_id=user_id,
                year=year,
                month=month,
                total_amount=Decimal(value)
            )
            db.session.add(record)
            db.session.commit()
            return record
        except Exception as e:
            db.session.rollback()
            raise e
    
    def fetch_monthly_expenses_raw(self, user_id: int) -> list:
        """
        Truy vấn tất cả bản ghi MonthlyExpense của user theo thứ tự tháng,
        rồi chuyển thành list of dict.
        """
        raw = MonthlyExpense.query.filter_by(user_id=user_id).order_by(MonthlyExpense.year, MonthlyExpense.month).all()
        return [record.to_dict() for record in raw]

    def get_monthly_record(self, user_id: int, year: int, month: int):
        print(f"\n--- DEBUG: Inside get_monthly_record ---")
        print(f"Attempting to fetch record for: UserID={user_id}, Year={year}, Month={month}")
        try:
            record = MonthlyExpense.query.filter_by(
                user_id=user_id,
                year=year,
                month=month
            ).first()
            
            if record:
                print(f"SUCCESS: Record FOUND. Total Amount: {record.total_amount}")
                # Nếu có thuộc tính target_value, cũng in ra
                if hasattr(record, 'target_value'):
                    print(f"SUCCESS: Record Target Value: {record.target_value}")
            else:
                print(f"NOT FOUND: No record found for UserID={user_id}, Year={year}, Month={month}")
            
            print(f"--- DEBUG: Exiting get_monthly_record ---")
            return record
        except Exception as e:
            # Ghi log lỗi nghiêm trọng nếu có vấn đề với truy vấn DB
            print(f"CRITICAL ERROR in MonthlyExpenseRepository: {e}")
            # Trong môi trường thực, bạn nên dùng thư viện logging thay vì print
            return None

    
    def update_monthly_target(user_id, year, month, target_value):
        """Tìm kiếm và cập nhật giá trị mục tiêu cho bản ghi MonthlyExpense."""
        record = MonthlyExpense.query.filter_by(
            user_id=user_id,
            year=year,
            month=month
        ).first()

        if record:
            record.target_value = target_value
            db.session.commit()
            return True # Trả về True nếu cập nhật thành công
        return False # Trả về False nếu không tìm thấy bản ghi