class MonthlyExpenseService:
    def __init__(self, expense_repository):
        self.expense_repository = expense_repository
    
    def get_monthly_expenses(self, user_id: int) -> list:
        # Lấy dữ liệu thô từ Repository
        raw_expenses_data = self.expense_repository.fetch_monthly_expenses_raw(user_id)
        return raw_expenses_data
    
    def create_expense(self, user_id: int, year: int, month: int, value: float):
        record = self.expense_repository.add_monthly_expense(user_id, year, month, value)
        return record
    
