class GrowthAnalyzer:
    def compute_recommendation(self, pct):
        if pct is None:
            return 'No previous data'
        if pct > 10:
            return 'Excellent growth – consider expanding'
        if pct > 0:
            return 'Positive trend – maintain course'
        if pct == 0:
            return 'Stable – no action needed'
        if pct >= -10:
            return 'Slight dip – investigate'
        return 'Significant drop – urgent review'

    def __calculate_growth_metrics(self, current_amount, previous_amount):
        """
        Tính toán phần trăm thay đổi và khuyến nghị cho một cặp giá trị.
        Trả về một dictionary chứa 'pct_change' và 'recommendation'.
        """
        if previous_amount is None or previous_amount == 0:
            pct = None
        else:
            pct = (current_amount - previous_amount) / previous_amount * 100
            pct = round(pct, 2)

        recommendation = self.compute_recommendation(pct)
        return {'pct_change': pct, 'recommendation': recommendation}
    
    def add_growth_metrics(self, data_list):
        """
        Thêm các chỉ số tăng trưởng (phần trăm thay đổi và khuyến nghị) vào mỗi bản ghi trong danh sách.
        Trả về danh sách đã được bổ sung.
        """
        processed_data = []
        for i, rec in enumerate(data_list):
            new_rec = rec.copy()  # Tạo bản sao để tránh sửa đổi bản gốc trực tiếp

            if i == 0:
                metrics = self.__calculate_growth_metrics(new_rec['total_amount'], None)
            else:
                prev_amount = data_list[i - 1]['total_amount']
                metrics = self.__calculate_growth_metrics(new_rec['total_amount'], prev_amount)

            new_rec.update(metrics)
            processed_data.append(new_rec)
        return processed_data
