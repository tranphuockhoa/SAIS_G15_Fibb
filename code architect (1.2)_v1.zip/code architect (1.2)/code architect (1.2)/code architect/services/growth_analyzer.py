from models.database_models import db, User 
from sqlalchemy.exc import SQLAlchemyError
from models.database_models import db, Expense 
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime

class GrowthAnalyzer:
    def compute_recommendation(self, pct):
        if pct is None:
            return 'No previous data'
        if pct > 10:
            return 'Excellent growth – consider expanding'
        if pct > 0:
            return 'Positive trend – maintain course'
        if pct == 0:
            return 'Stable – no action needed'
        if pct >= -10:
            return 'Slight dip – investigate'
        return 'Significant drop – urgent review'

    def __calculate_growth_metrics(self, current_amount, previous_amount):
        """
        Tính toán phần trăm thay đổi và khuyến nghị cho một cặp giá trị.
        Trả về một dictionary chứa 'pct_change' và 'recommendation'.
        """
        if previous_amount is None or previous_amount == 0:
            pct = None
        else:
            pct = (current_amount - previous_amount) / previous_amount * 100
            pct = round(pct, 2)

        recommendation = self.compute_recommendation(pct)
        return {'pct_change': pct, 'recommendation': recommendation}
    
    def add_growth_metrics(self, data_list):
        """
        Thêm các chỉ số tăng trưởng (phần trăm thay đổi và khuyến nghị) vào mỗi bản ghi trong danh sách.
        Trả về danh sách đã được bổ sung.
        """
        processed_data = []
        for i, rec in enumerate(data_list):
            new_rec = rec.copy()  # Tạo bản sao để tránh sửa đổi bản gốc trực tiếp

            if i == 0:
                metrics = self.__calculate_growth_metrics(new_rec['total_amount'], None)
            else:
                prev_amount = data_list[i - 1]['total_amount']
                metrics = self.__calculate_growth_metrics(new_rec['total_amount'], prev_amount)

            new_rec.update(metrics)
            processed_data.append(new_rec)
        return processed_data
    
# THÊM HÀM XÓA NGƯỜI DÙNG Ở ĐÂY
def delete_user_by_id(user_id: int):
    """
    Tìm và xóa người dùng dựa trên ID.
    """
    try:
        user = db.session.get(User, user_id)

        if not user:
            return False, "User not found"

        db.session.delete(user)
        db.session.commit()
        
        return True, f"User {user_id} deleted successfully"

    except SQLAlchemyError as e:
        db.session.rollback()
        return False, f"Database error: {str(e)}"
    except Exception as e:
        db.session.rollback()
        return False, f"An unexpected error occurred: {str(e)}"
    
def delete_expenses_by_user_and_date(user_id: int, date_str: str):
    """
    Xóa tất cả chi tiêu của một người dùng trong một ngày cụ thể.
    """
    try:
        date_to_delete = datetime.strptime(date_str, '%Y-%m-%d').date()

        # Lọc các bản ghi theo user_id và ngày (giả sử bạn có model Expense)
        # db.cast(Expense.date, db.Date) giúp so sánh chỉ phần ngày của cột datetime
        deleted_count = db.session.query(Expense).filter(
            Expense.user_id == user_id,
            db.cast(Expense.date, db.Date) == date_to_delete
        ).delete(synchronize_session=False)

        db.session.commit()

        if deleted_count == 0:
            return True, 0, "Không tìm thấy chi tiêu nào để xóa."
        else:
            return True, deleted_count, f"Đã xóa thành công {deleted_count} dòng dữ liệu cho User {user_id} vào ngày {date_str}."

    except ValueError:
        db.session.rollback()
        return False, 0, "Ngày không hợp lệ. Vui lòng sử dụng định dạng YYYY-MM-DD."
    except SQLAlchemyError as e:
        db.session.rollback()
        return False, 0, f"Lỗi cơ sở dữ liệu: {str(e)}"
    except Exception as e:
        db.session.rollback()
        return False, 0, f"Lỗi không mong muốn: {str(e)}"
