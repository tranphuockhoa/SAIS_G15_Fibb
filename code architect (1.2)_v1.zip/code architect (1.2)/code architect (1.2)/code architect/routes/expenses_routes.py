from flask import Blueprint, request, jsonify
from services.expense_service import get_all_expenses_logic, create_expense_logic, get_expenses_by_user_logic
from api_validation import validate_required_fields

expense_bp = Blueprint('expense_routes', __name__)

@expense_bp.route('/', methods=['POST'])
def record_expense():

    data = request.get_json()

    required_fields = ['user_id', 'amount', 'category_id', 'note']

    error_response, status_code = validate_required_fields(data, required_fields)
    if error_response:
        return error_response, status_code

    user_id = data['user_id']
    amount = data['amount']
    category_id = data['category_id']
    note = data.get('note')
    date_str = data.get('date')

    new_expense, error_message, status_code = create_expense_logic(
        user_id, amount, category_id, note, date_str
    )

    if error_message:
        return jsonify({"error": error_message}), status_code

    return jsonify({"message": "Chi tiêu đã được ghi nhận thành công", "expense": new_expense}), status_code

@expense_bp.route('/', methods=['GET'])
def get_expenses():
    """
    Lấy danh sách tất cả các chi tiêu hoặc chi tiêu của một người dùng cụ thể.
    Yêu cầu (tùy chọn): Tham số query 'user_id'.
    Phản hồi: Danh sách các đối tượng chi tiêu.
    """
    user_id = request.args.get('user_id')
    if user_id:
        return get_expenses_by_user_logic(user_id)
    else:
        return get_all_expenses_logic()