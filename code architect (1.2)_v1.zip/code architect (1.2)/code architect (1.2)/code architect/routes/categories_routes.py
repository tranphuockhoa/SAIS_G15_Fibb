from flask import Blueprint, request, jsonify
# Import các hàm logic cần thiết
from services.category_service import get_all_categories_logic, create_category_logic

# Tạo một Blueprint mới cho các route liên quan đến Category
category_bp = Blueprint('category_routes', __name__)

@category_bp.route('/', methods=['GET'])
def get_all_categories():
    """
    Lấy danh sách tất cả các danh mục.
    Phản hồi: Danh sách các đối tượng danh mục.
    """
    return get_all_categories_logic()

@category_bp.route('/', methods=['POST'])
def add_category():
    """
    Thêm một danh mục mới.
    Yêu cầu: JSON body với trường 'name'.
    Phản hồi: Thông báo thành công và thông tin danh mục mới hoặc lỗi.
    """
    data = request.get_json()

    if not data or 'name' not in data:
        return jsonify({"error": "Thiếu trường bắt buộc: 'name'"}), 400

    category_name = data['name']

    new_category, error_message, status_code = create_category_logic(category_name)

    if error_message:
        return jsonify({"error": error_message}), status_code

    return jsonify({"message": "Danh mục đã được thêm thành công", "category": new_category}), status_code