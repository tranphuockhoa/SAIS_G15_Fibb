from flask import request

class RequestParser:
    def parse_target_request_data():
        """Phân tích dữ liệu JSON từ yêu cầu và trả về user_id, month_str, target_value."""
        data = request.get_json()
        user_id = data.get('user_id')
        month_str = data.get('month')
        target_value = float(data.get('target_value', 0))
        return user_id, month_str, target_value

    def extract_year_and_month(month_str):
        """Trích xuất năm và tháng từ chuỗi 'YYYY-MM'."""
        if not month_str:
            raise ValueError("Month string cannot be empty.")
        try:
            year, month = map(int, month_str.split('-'))
            return year, month
        except ValueError:
            raise ValueError("Invalid month format. Expected 'YYYY-MM'.")
    