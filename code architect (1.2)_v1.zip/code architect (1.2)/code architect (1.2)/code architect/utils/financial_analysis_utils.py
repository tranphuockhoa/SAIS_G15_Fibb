class FinancialAnalysisUtils:
    @staticmethod
    def compare_with_target(current_value, target_value):
        if target_value is not None and current_value is not None:
            return {
                'exceeded': current_value > target_value,
                'difference': current_value - target_value if current_value > target_value else 0
            }
        return None

    @staticmethod
    def compare_with_previous(current_value, previous_value):
        if previous_value is not None and current_value is not None:
            return {
                'increased': current_value > previous_value,
                'difference': current_value - previous_value
            }
        return None
